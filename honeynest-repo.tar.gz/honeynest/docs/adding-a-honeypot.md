# Adding a honeypot

1. Create `honeypots/hn/mything.py`:
```python
from .common import Service, Session

class MyThingService(Service):
    name = "mything"
    async def handle(self, s: Session) -> None:
        await s.send(b"HELLO\r\n")
        line = await s.readline(1024)          # bounded read with idle timeout
        s.log("command", command=line.decode("utf-8", "replace").strip())
```
2. Register it in `REGISTRY` in `honeypots/hn/__main__.py` (`"mything": (MyThingService, "mything", "HN_PORT_MYTHING", "9999")`).
3. Publish the port in `docker-compose.yml` under the appropriate container and add `HN_HOST_MYTHING` to `.env.example`.
4. Add a test in `tests/test_honeypots.py` and add it to `SERVICES` in `tests/test_robustness.py`.
5. Use standard event names (`auth` with `username`/`password`/`success`, `command`, `payload`) so the dashboard picks them up automatically.
