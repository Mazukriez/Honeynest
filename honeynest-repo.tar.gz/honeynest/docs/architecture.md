# Architecture

```
attacker ─► hp-remote-access (ssh, telnet) ─┐
attacker ─► hp-web           (http, https)  ├─► hn-logs volume (JSONL, rotating) ─┐ read-only
attacker ─► hp-services      (ftp, smtp, redis, mysql, tcp) ─┘                   ▼
                                                              dashboard: Ingestor ─► SQLite ─► REST API ─► UI
```
* **Honeypots** (`honeypots/hn/`) share one image; `HN_SERVICES` picks which run in a container. Each connection is wrapped by
  `Service._wrap` which enforces limits/timeouts and always emits `connect` / `disconnect`.
* **Event schema**: `ts, sensor, service, event, src_ip, src_port, dst_port, session, data{}`.
* **Ingestor** tails `*.jsonl` by (inode, offset) stored in the same transaction as the inserted rows (exactly-once),
  tolerates partial lines, and finishes the rotated `.1` file before switching to the new one.
* **Network**: honeypots on `honeynet` (egress blockable via `scripts/egress-lockdown.sh`); dashboard on a separate network and
  only shares a read-only volume with them — no network path from honeypots to the dashboard.
