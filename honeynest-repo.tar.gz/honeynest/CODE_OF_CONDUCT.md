# Code of Conduct
This project follows the [Contributor Covenant v2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).
Be respectful and constructive. Report unacceptable behaviour to the maintainers via a private GitHub security advisory
or the contact listed on the repository profile; reports are handled confidentially.
