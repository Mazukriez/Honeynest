# Changelog
All notable changes to this project are documented here. Format: [Keep a Changelog](https://keepachangelog.com/), versioning: [SemVer](https://semver.org/).

## [1.0.0] - 2026-10-11
### Added
- Honeypots: SSH, Telnet, HTTP/HTTPS, FTP, SMTP, Redis, MySQL, generic TCP catch-all.
- Dashboard (FastAPI + SQLite): live events, timeline, top-N lists, attacker drill-down, search, CSV/NDJSON export, Prometheus metrics, webhook alerts, optional GeoIP.
- Hardened Docker Compose stack, `install.sh`, `hnctl`, `scripts/egress-lockdown.sh`.
- 28 tests including fuzzing and end-to-end ingestion.
