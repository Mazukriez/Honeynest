# Honeynest

[![CI](https://github.com/OWNER/honeynest/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/honeynest/actions/workflows/ci.yml) [![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

A multi-honeypot platform you can install with one command. It listens on the ports attackers
scan most, pretends to be vulnerable, records everything they try, and shows it in a built-in
dashboard. Inspired by T-Pot, but lightweight: **4 small containers, under 200 MB RAM at idle, no Elasticsearch.**

```
 Internet ──► :22 :23 ─► hp-remote-access  (SSH, Telnet)      ┐
          ──► :80 :443 ► hp-web            (HTTP, HTTPS)       ├─ JSONL events ─► dashboard ─► http://127.0.0.1:9000
          ──► :21 :25 :3306 :6379 :445 … ► hp-services         ┘   (read-only)     SQLite + REST API + UI
```

## What it emulates

| Service | Ports | What you learn |
|---|---|---|
| **SSH** (asyncssh) | 22 | Usernames/passwords, public keys offered, every shell command, download URLs, port-forward attempts. Lets attackers "in" after N tries into a fake Debian shell. |
| **Telnet** | 23 | Mirai-style IoT botnet logins and `busybox` droppers |
| **HTTP / HTTPS** | 80, 443 | Fake WordPress, phpMyAdmin, Tomcat Manager, generic admin login, decoy `.env`/`.git`; tags Log4Shell, Shellshock, SQLi, XSS, traversal, command injection, PHPUnit RCE, IoT exploits, scanners |
| **FTP** | 21 | Credentials and commands |
| **SMTP** | 25 | AUTH credentials, spam/phishing mail bodies (accepted and discarded, never relayed) |
| **Redis** | 6379 | Unauthenticated-Redis attacks (`CONFIG SET dir`, `SLAVEOF`, `MODULE LOAD`, cron/SSH-key writes) |
| **MySQL** | 3306 | Usernames + the auth scramble & salt (crackable offline) |
| **TCP catch-all** | 445, 3389, 5900, 1433, 5432, 27017, 11211, 1883 | First bytes of every probe + protocol fingerprint (SMB, RDP, TLS, VNC…) |

**Dashboard:** live events, activity timeline, top IPs / countries / usernames / passwords / commands /
paths / user-agents / ports, per-attacker drill-down, full-text search, NDJSON & CSV export,
Prometheus `/metrics`, optional Slack/Discord/Mattermost webhook alerts.

## Install

Requirements: a **dedicated** Linux VM/VPS (1 vCPU / 1 GB RAM is plenty), Docker Engine + Compose v2.

```bash
# from a GitHub release tarball:  tar xzf honeynest-1.0.0.tar.gz && cd honeynest-1.0.0
# or from git:                     git clone https://github.com/OWNER/honeynest.git && cd honeynest
sudo ./install.sh                  # add --install-docker if Docker is missing
```

The installer generates a strong dashboard password, writes `.env` (mode 600), detects host-port
conflicts (it will move a honeypot to a free port and tell you), builds and starts everything. It never
touches your sshd or firewall.

Then:

```bash
./hnctl selftest                   # generate a couple of harmless probes
ssh -L 9000:127.0.0.1:9000 you@your-server    # reach the dashboard from your laptop
# open http://127.0.0.1:9000  (user admin, password printed by the installer / ./hnctl password)
sudo ./scripts/egress-lockdown.sh --persist   # strongly recommended, see "Hardening"
```

### Moving your real SSH (so the honeypot can own port 22)
Attackers hit port 22. To catch them, move your *admin* SSH first — and keep your current session open
until you have verified the new port:
```bash
sudo sed -i 's/^#\?Port .*/Port 2200/' /etc/ssh/sshd_config
sudo systemctl restart ssh      # (or sshd)    # open a NEW terminal: ssh -p 2200 you@host
# allow 2200 in your cloud firewall/security group, then re-run ./install.sh  (it will now claim 22)
```
If port 22 is busy, Honeynest falls back to 2222 so it still works (with less traffic).

## Everyday use

```bash
./hnctl status        ./hnctl logs [service]     ./hnctl restart
./hnctl backup        ./hnctl update             ./hnctl password
./hnctl uninstall     # deletes containers, logs and the database
```

## Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `HN_SENSOR`, `HN_HOSTNAME` | `honeynest-1`, `web-prod-02` | Sensor name in the dashboard / hostname shown in fake shells |
| `HN_HOST_SSH/TELNET/HTTP/HTTPS/…` | 22/23/80/443/… | Host ports (see `.env.example` for all) |
| `HN_SSH_ACCEPT_AFTER` | 3 | Accept an IP's Nth password attempt (1 = accept first; `HN_SSH_ACCEPT_ANY=1` in compose to accept all) |
| `HN_MAX_CONNECTIONS` / `HN_MAX_PER_IP` | 500 / 20 | Concurrency caps |
| `DASH_BIND` / `DASH_PORT` | `127.0.0.1` / 9000 | Where the dashboard listens |
| `DASH_PASSWORD` | generated | ≥ 12 chars or the dashboard refuses to start |
| `RETENTION_DAYS` | 90 | Old events are purged hourly |
| `ALERT_WEBHOOK_URL` | – | Alerts on successful logins, download attempts, `curl \| sh` droppers (rate-limited per IP) |
| `GEOIP_DIR` | `./geoip` | Put a free MaxMind `GeoLite2-Country.mmdb` there for country stats |

Apply changes with `docker compose up -d`.

## Hardening checklist
1. **Dedicated host, isolated network.** Never run next to anything you care about.
2. **`sudo ./scripts/egress-lockdown.sh --persist`** — drops new outbound connections from the honeypot network
   (Docker `DOCKER-USER` chain). The honeypots never need to call out. IPv4 only; disable IPv6 in Docker
   or add equivalent `ip6tables` rules.
3. **Don't publish the dashboard.** It's loopback-only; use an SSH tunnel, or a TLS reverse proxy (Caddy/nginx) with the
   Basic-auth login as a second layer.
4. Keep Docker and the host patched. Rebuild periodically: `./hnctl update`.
5. Source IPs are preserved for IPv4 published ports. If you enable Docker's IPv6, verify attacker IPs aren't
   masked as the bridge gateway.

Details and guarantees: [SECURITY.md](SECURITY.md). Internals: [docs/architecture.md](docs/architecture.md). Contributing: [CONTRIBUTING.md](CONTRIBUTING.md).

## Data format & integrations

Events are JSONL in the `hn-logs` volume (`docker run --rm -v honeynest_hn-logs:/l alpine cat /l/ssh.jsonl`), one object per line:
```json
{"ts":"2026-10-11T03:14:22.123+00:00","sensor":"honeynest-1","service":"ssh","event":"auth",
 "src_ip":"203.0.113.7","src_port":51544,"dst_port":22,"session":"9f1c2a7be310",
 "data":{"username":"root","password":"123456","success":false,"method":"password"}}
```
Events: `connect`, `auth`, `login_success`, `command`, `request`, `download_attempt`, `pipe_to_shell`,
`file_write`, `payload`, `mail`, `tunnel_attempt`, `disconnect` …

REST API (Basic auth): `/api/summary`, `/api/timeline`, `/api/top?field=`, `/api/events`, `/api/attacker/{ip}`,
`/api/export?fmt=csv|ndjson`, `/metrics` (Prometheus), `/healthz` (unauthenticated, no data).
To ship to Elastic/Loki/Splunk, point Filebeat/Promtail/Vector at the log volume.

## Extending
A honeypot is ~50 lines: subclass `Service`, implement `async handle(self, s: Session)`, call `s.log("event", key=value)`,
and register it in `honeypots/hn/__main__.py`. Bounds, limits, timeouts and logging come for free.

## Development
```bash
pip install -r requirements-dev.txt && make test     # 28 tests incl. fuzzing and end-to-end
make dist                                            # release tarball in dist/
```

## Honest limitations (vs. T-Pot)
Honeynest uses **low/medium-interaction emulation written from scratch**, not full third-party honeypots
(Cowrie, Dionaea, Conpot…). It is excellent for volume/credential/botnet/exploit-scan intelligence and has a tiny attack
surface; it will not capture malware binaries (it deliberately never downloads attacker URLs), and a skilled human
may eventually recognise the emulation. Possible next steps: more protocols (SIP, Elasticsearch, ICS), STARTTLS, a
Filebeat/OpenSearch profile.

## Legal & ethics
Operate honeypots only on infrastructure you own, within your provider's terms and local law. Captured
credentials and IPs can be personal data (e.g. GDPR) — set `RETENTION_DAYS` appropriately.
No warranty; MIT license.
