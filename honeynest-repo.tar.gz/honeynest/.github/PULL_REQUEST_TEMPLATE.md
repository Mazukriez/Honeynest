## What & why

## Checklist
- [ ] `make test` and `make lint` pass
- [ ] Nothing attacker-controlled is executed, fetched or rendered as HTML
- [ ] New/changed service has tests (incl. robustness list)
- [ ] `CHANGELOG.md` updated
