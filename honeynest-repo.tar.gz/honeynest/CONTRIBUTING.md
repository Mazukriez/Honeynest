# Contributing

Thanks for helping! Bug reports, new honeypot protocols, detection tags and docs are all welcome.

## Setup
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
make test        # must pass
make lint
```

## Ground rules (security tool — these are non-negotiable)
1. **Never execute, evaluate, or fetch anything an attacker sends.** Emulate output; log intent.
2. **Everything is bounded**: read sizes, line lengths, timeouts, loop counts. Use `Session.readline/read` helpers.
3. **Attacker text is hostile everywhere**: dashboard code uses `textContent` only; CSV export neutralises formulas; SQL is parameterised (column names whitelisted).
4. New services need an integration test in `tests/test_honeypots.py` and an entry in `tests/test_robustness.py`.
5. No new runtime dependency without a strong reason (the footprint is a feature).

## Pull requests
Branch from `main`, keep PRs focused, update `CHANGELOG.md` under *Unreleased*, and fill in the PR template.
See [docs/adding-a-honeypot.md](docs/adding-a-honeypot.md) for a walkthrough.

Security issues: **do not open a public issue** — see [SECURITY.md](SECURITY.md).
