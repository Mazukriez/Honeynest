#!/usr/bin/env bash
# Honeynest installer. Safe to re-run. Does NOT modify your sshd or firewall.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

START=1; INSTALL_DOCKER=0
for a in "$@"; do case "$a" in
  --no-start) START=0 ;;
  --install-docker) INSTALL_DOCKER=1 ;;
  -h|--help) echo "Usage: $0 [--no-start] [--install-docker]"; exit 0 ;;
  *) echo "Unknown option: $a" >&2; exit 2 ;;
esac; done

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_ylw=$'\e[33m'; c_off=$'\e[0m'
info(){ echo "${c_grn}==>${c_off} $*"; }
warn(){ echo "${c_ylw}WARN:${c_off} $*" >&2; }
die(){ echo "${c_red}ERROR:${c_off} $*" >&2; exit 1; }

[ "$(uname -s)" = "Linux" ] || warn "Honeynest is developed for Linux hosts; other platforms are best-effort."

# --- Docker ---------------------------------------------------------------
if ! command -v docker >/dev/null 2>&1; then
  if [ "$INSTALL_DOCKER" = 1 ]; then
    info "Installing Docker via the official convenience script (https://get.docker.com)"
    curl -fsSL https://get.docker.com | sh
  else
    die "Docker is not installed. Install it (https://docs.docker.com/engine/install/) or re-run with --install-docker."
  fi
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 plugin is required (docker compose ...)."
docker info >/dev/null 2>&1 || die "Cannot talk to the Docker daemon. Is it running, and are you in the 'docker' group (or root)?"

# --- .env -----------------------------------------------------------------
[ -f .env ] || { cp .env.example .env; info "Created .env"; }
chmod 600 .env
getv(){ grep -E "^$1=" .env | tail -1 | cut -d= -f2- | sed 's/[[:space:]]*#.*$//'; }
setv(){ if grep -qE "^$1=" .env; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi; }

GENERATED=""
if [ "$(getv DASH_PASSWORD | tr -d ' ')" = "" ]; then
  GENERATED="$(head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)"
  [ ${#GENERATED} -ge 20 ] || die "Could not generate a password"
  setv DASH_PASSWORD "$GENERATED"
fi

# --- port conflicts -------------------------------------------------------
in_use(){
  if command -v ss >/dev/null 2>&1; then ss -ltnH 2>/dev/null | awk '{print $4}' | grep -qE "[:.]$1\$"
  else (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; fi
}
check_port(){  # name default
  local var="HN_HOST_$1" def="$2" cur; cur="$(getv "$var")"; cur="${cur:-$def}"
  if in_use "$cur"; then
    local alt=$((10000 + def)); [ "$1" = SSH ] && alt=2222; [ "$1" = TELNET ] && alt=2323
    warn "Host port $cur ($1) is already in use -> honeypot will listen on $alt instead."
    [ "$1" = SSH ] && warn "To catch real SSH attacks on 22, move your admin sshd to another port first (see README: 'Moving your real SSH')."
    setv "$var" "$alt"
  fi
}
for p in SSH:22 TELNET:23 HTTP:80 HTTPS:443 FTP:21 SMTP:25 REDIS:6379 MYSQL:3306 SMB:445 MSSQL:1433 \
         RDP:3389 POSTGRES:5432 VNC:5900 MEMCACHED:11211 MONGO:27017 MQTT:1883; do
  check_port "${p%%:*}" "${p##*:}"
done

# --- start ----------------------------------------------------------------
if [ "$START" = 1 ]; then
  info "Building and starting Honeynest (first build takes a minute or two)..."
  docker compose up -d --build
  info "Waiting for containers to become healthy..."
  for _ in $(seq 1 40); do
    unhealthy=$(docker compose ps --format '{{.Name}} {{.Health}}' | grep -vc ' healthy' || true)
    [ "$unhealthy" = 0 ] && break; sleep 3
  done
  docker compose ps
fi

DPORT="$(getv DASH_PORT)"; DPORT="${DPORT:-9000}"
echo
info "Honeynest is installed."
echo "  Dashboard : http://127.0.0.1:${DPORT}   (loopback only; remote: ssh -L ${DPORT}:127.0.0.1:${DPORT} you@this-host)"
echo "  Username  : $(getv DASH_USER)"
if [ -n "$GENERATED" ]; then echo "  Password  : $GENERATED   (also stored in .env, mode 600)"; else echo "  Password  : see DASH_PASSWORD in .env"; fi
echo "  Manage    : ./hnctl status | logs | stop | update | selftest"
echo
warn "Run this on a dedicated, internet-facing host/VM/VPS, NOT on a production server."
warn "Strongly recommended: sudo ./scripts/egress-lockdown.sh  (blocks outbound traffic from the honeypot containers)."
