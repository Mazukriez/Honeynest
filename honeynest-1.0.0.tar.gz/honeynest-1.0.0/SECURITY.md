# Security policy

Honeynest is a *deception* tool: it is designed to be attacked. Its own security properties matter in two ways.

## Safe-by-design guarantees (and where they are tested)
| Guarantee | Where |
|---|---|
| Nothing an attacker sends is ever executed; the fake shell is a pure text emulator | `honeypots/hn/shell.py`, `tests/test_shell.py::test_never_executes_real_commands` |
| The honeypot never downloads attacker URLs (no SSRF / malware handling) — URLs are only *logged* | `shell.py` |
| Every connection is bounded: global + per-IP limits, idle + session timeouts, byte caps | `hn/common.py` |
| Hostile input cannot crash a service | `tests/test_robustness.py` (fuzzing) |
| Containers: non-root (uid 10001), read-only rootfs, all capabilities dropped, `no-new-privileges`, pid/mem/cpu limits | `docker-compose.yml` |
| Dashboard is authenticated (HTTP Basic, constant-time compare), refuses to start with a weak password, binds to loopback by default, strict CSP, no CDN | `dashboard/app/main.py` |
| Attacker-controlled text can't XSS the dashboard (`textContent` only) or inject formulas into CSV exports | `static/app.js`, `tests/test_dashboard.py` |
| Dashboard reads raw logs through a **read-only** mount | `docker-compose.yml` |

## Residual risks — read before deploying
* Run Honeynest on a **dedicated VM/VPS** in an isolated network segment, never next to production systems.
* Apply `scripts/egress-lockdown.sh` so a compromised honeypot can't attack third parties.
* Credentials that attackers type are stored in clear text (that is the point). Treat logs as sensitive.
* The decoy `.env` contains obviously fake secrets (`...DECOY`, AWS docs' `EXAMPLE` keys). Never place real secrets in a honeypot.
* Do not expose the dashboard to the internet without a TLS reverse proxy.

## Reporting a vulnerability
Please open a private security advisory on the repository (or email the maintainers) rather than a public issue.
