"""Telnet honeypot (Mirai-style IoT targets). Captures logins and shell commands."""
from __future__ import annotations

import re

from .common import Service, Session, env, env_int
from .shell import FakeShell

IAC, DONT, DO, WONT, WILL, SB, SE = 255, 254, 253, 252, 251, 250, 240
IAC_RE = re.compile(rb"\xff[\xfb-\xfe].|\xff\xfa.*?\xff\xf0|\xff.", re.S)


def strip_iac(data: bytes) -> bytes:
    return IAC_RE.sub(b"", data)


class TelnetService(Service):
    name = "telnet"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.accept_after = env_int("HN_TELNET_ACCEPT_AFTER", 2)
        self.hostname = env("HN_HOSTNAME", "web-prod-02")
        self.attempts: dict[str, int] = {}

    async def _prompt(self, s: Session, text: str, echo: bool = True) -> str | None:
        await s.send(text)
        raw = await s.readline(256)
        if not raw:
            return None
        return strip_iac(raw).decode("utf-8", "replace").strip("\r\n\x00 ")

    async def handle(self, s: Session) -> None:
        # Negotiate: we echo, suppress go-ahead (best-effort; scanners ignore it).
        await s.send(bytes([IAC, WILL, 1, IAC, WILL, 3]))
        for _ in range(5):
            user = await self._prompt(s, f"\r\n{self.hostname} login: ")
            if user is None:
                return
            pw = await self._prompt(s, "Password: ", echo=False)
            if pw is None:
                return
            n = self.attempts.get(s.ip, 0) + 1
            self.attempts[s.ip] = n
            ok = bool(user) and n >= self.accept_after
            s.log("auth", username=user, password=pw, success=ok, method="password")
            if ok:
                s.log("login_success", username=user, password=pw)
                break
            await s.send("\r\nLogin incorrect\r\n")
        else:
            return

        shell = FakeShell(user=user if user != "admin" else "root", hostname=self.hostname,
                          on_event=lambda e, **d: s.log(e, **d))
        s.log("shell_open")
        await s.send("\r\nBusyBox v1.30.1 built-in shell (ash)\r\n")
        while not shell.exited:
            await s.send(shell.prompt)
            raw = await s.readline(2048)
            if not raw:
                break
            line = strip_iac(raw).decode("utf-8", "replace").strip("\r\n\x00")
            s.log("command", command=line, cwd=shell.cwd)
            out = shell.run(line)
            if out:
                await s.send(out.replace("\n", "\r\n"))
