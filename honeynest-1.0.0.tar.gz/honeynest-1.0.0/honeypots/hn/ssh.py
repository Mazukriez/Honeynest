"""SSH honeypot (asyncssh). Logs credentials, public keys, commands, tunnels."""
from __future__ import annotations

import asyncio
import os
import time
import uuid
from typing import Any

import asyncssh

from .common import EventLogger, Limiter, env, env_bool, env_int
from .shell import FakeShell

SSH_BANNER = env("HN_SSH_VERSION", "OpenSSH_8.4p1 Debian-5+deb11u3")


def ensure_host_keys(key_dir: str) -> list[str]:
    """Create persistent host keys (stable fingerprints look like a real host)."""
    os.makedirs(key_dir, exist_ok=True)
    paths = []
    for alg, fname in (("ssh-ed25519", "ssh_host_ed25519_key"), ("ssh-rsa", "ssh_host_rsa_key")):
        p = os.path.join(key_dir, fname)
        if not os.path.exists(p):
            key = asyncssh.generate_private_key(alg, **({"key_size": 3072} if alg == "ssh-rsa" else {}))
            key.write_private_key(p)
            os.chmod(p, 0o600)
        paths.append(p)
    return paths


class _Server(asyncssh.SSHServer):
    def __init__(self, svc: "SSHService"):
        self.svc = svc
        self.sid = uuid.uuid4().hex[:12]
        self.ip = "?"
        self.port = 0
        self.t0 = time.monotonic()
        self.tries = 0
        self.client_version = ""
        self._counted = False

    def _log(self, event: str, **d: Any) -> None:
        self.svc.log.emit(event, self.ip, self.port, self.svc.listen_port, self.sid, **d)

    def connection_made(self, conn: asyncssh.SSHServerConnection) -> None:
        peer = conn.get_extra_info("peername") or ("?", 0)
        self.ip, self.port = str(peer[0]).split("%")[0], int(peer[1])
        if self.ip.lower().startswith("::ffff:"):
            self.ip = self.ip[7:]
        self.conn = conn
        if not self.svc.limiter.acquire(self.ip):
            self._log("limit_exceeded")
            conn.abort()
            return
        self._counted = True
        self.svc.by_peer[(self.ip, self.port)] = self.sid
        self._log("connect")

    def connection_lost(self, exc: Exception | None) -> None:
        self.svc.by_peer.pop((self.ip, self.port), None)
        if self._counted:
            self.svc.limiter.release(self.ip)
            self._log("disconnect", duration=round(time.monotonic() - self.t0, 2),
                      client_version=self.conn.get_extra_info("client_version", ""),
                      **({"reason": type(exc).__name__} if exc else {}))

    def begin_auth(self, username: str) -> bool:
        return True

    def password_auth_supported(self) -> bool:
        return True

    def public_key_auth_supported(self) -> bool:
        return True

    def validate_password(self, username: str, password: str) -> bool:
        self.tries += 1
        n = self.svc.attempts.get(self.ip, 0) + 1
        self.svc.attempts[self.ip] = n
        ok = bool(password) and (self.svc.accept_any or n >= self.svc.accept_after)
        self._log("auth", username=username, password=password, success=ok, method="password",
                  client_version=self.conn.get_extra_info("client_version", ""))
        if ok:
            self._log("login_success", username=username, password=password)
        return ok

    def validate_public_key(self, username: str, key: asyncssh.SSHKey) -> bool:
        self._log("auth", username=username, method="publickey", success=False,
                  key_type=key.algorithm.decode(), fingerprint=key.get_fingerprint())
        return False

    def connection_requested(self, dest_host: str, dest_port: int, orig_host: str, orig_port: int) -> bool:
        self._log("tunnel_attempt", dest_host=dest_host, dest_port=dest_port)
        return False

    def server_requested(self, listen_host: str, listen_port: int) -> bool:
        self._log("remote_forward_attempt", listen_host=listen_host, listen_port=listen_port)
        return False


class SSHService:
    name = "ssh"

    def __init__(self, log: EventLogger, limiter: Limiter, cfg: dict[str, Any] | None = None):
        self.log = log
        self.limiter = limiter
        cfg = cfg or {}
        self.key_dir = cfg.get("key_dir", "/data/state/keys")
        self.accept_after = env_int("HN_SSH_ACCEPT_AFTER", 3)
        self.accept_any = env_bool("HN_SSH_ACCEPT_ANY", False)
        self.hostname = env("HN_HOSTNAME", "web-prod-02")
        self.listen_port = 0
        self.attempts: dict[str, int] = {}
        self.by_peer: dict[tuple[str, int], str] = {}
        self.acceptor: Any = None
        self.idle = env_int("HN_IDLE_TIMEOUT", 120)
        self.session_timeout = env_int("HN_SESSION_TIMEOUT", 300)

    async def start(self, host: str, port: int, ssl: Any = None) -> None:
        self.listen_port = port
        self.acceptor = await asyncssh.listen(
            host, port, server_factory=lambda: _Server(self),
            server_host_keys=ensure_host_keys(self.key_dir),
            process_factory=self._process, server_version=SSH_BANNER,
            login_timeout=30, keepalive_interval=30, keepalive_count_max=2,
            encoding="utf-8", line_editor=True, reuse_address=True,
            allow_scp=False, sftp_factory=None)

    async def stop(self) -> None:
        if self.acceptor:
            self.acceptor.close()
            await self.acceptor.wait_closed()

    # ---- interactive / exec session ----
    async def _process(self, process: asyncssh.SSHServerProcess) -> None:
        peer = process.get_extra_info("peername") or ("?", 0)
        ip = str(peer[0]).split("%")[0]
        if ip.lower().startswith("::ffff:"):
            ip = ip[7:]
        sid = self.by_peer.get((ip, int(peer[1])), "unknown")
        user = process.get_extra_info("username") or "root"

        def ev(event: str, **d: Any) -> None:
            self.log.emit(event, ip, int(peer[1]), self.listen_port, sid, **d)

        shell = FakeShell(user=user, hostname=self.hostname, on_event=ev)
        deadline = time.monotonic() + self.session_timeout
        try:
            if process.command is not None:  # ssh host 'cmd'
                ev("command", command=process.command, mode="exec")
                process.stdout.write(shell.run(process.command))
                process.exit(0)
                return
            ev("shell_open", term=process.get_terminal_type())
            process.stdout.write("Linux web-prod-02 5.10.0-21-amd64 #1 SMP Debian 5.10.162-1 x86_64\n\n"
                                 "Last login: Tue Oct  6 03:14:22 2026 from 10.0.0.5\n")
            while not shell.exited and time.monotonic() < deadline:
                process.stdout.write(shell.prompt)
                try:
                    line = await asyncio.wait_for(process.stdin.readline(), self.idle)
                except asyncio.TimeoutError:
                    break
                if not line:
                    break
                ev("command", command=line.strip(), mode="shell", cwd=shell.cwd)
                process.stdout.write(shell.run(line))
            process.exit(0)
        except (asyncssh.Error, ConnectionError, OSError):
            process.exit(1)
