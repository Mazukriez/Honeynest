"""Container healthcheck: the runner touches /tmp/hn.ready every 15s."""
import sys
import time

try:
    age = time.time() - float(open("/tmp/hn.ready").read())
except (OSError, ValueError):
    sys.exit(1)
sys.exit(0 if age < 60 else 1)
