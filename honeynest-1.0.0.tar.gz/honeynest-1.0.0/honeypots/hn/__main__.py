"""Honeynest honeypot runner:  python -m hn   (services chosen by HN_SERVICES)."""
from __future__ import annotations

import asyncio
import logging
import os
import signal
import socket
import time

from .common import EventLogger, Limiter, env, env_int, parse_ports
from .mail_ftp import FTPService, SMTPService
from .redis_mysql import MySQLService, RedisService
from .ssh import SSHService
from .tcp_catchall import TCPCatchAll
from .telnet import TelnetService
from .web import HTTPService, make_ssl_context

READY_FILE = "/tmp/hn.ready"

# service -> (class, log name, env var for ports, default ports)
REGISTRY = {
    "ssh": (SSHService, "ssh", "HN_PORT_SSH", "22"),
    "telnet": (TelnetService, "telnet", "HN_PORT_TELNET", "23"),
    "http": (HTTPService, "http", "HN_PORT_HTTP", "80"),
    "https": (HTTPService, "http", "HN_PORT_HTTPS", "443"),
    "ftp": (FTPService, "ftp", "HN_PORT_FTP", "21"),
    "smtp": (SMTPService, "smtp", "HN_PORT_SMTP", "25"),
    "redis": (RedisService, "redis", "HN_PORT_REDIS", "6379"),
    "mysql": (MySQLService, "mysql", "HN_PORT_MYSQL", "3306"),
    "tcp": (TCPCatchAll, "tcp", "HN_PORT_TCP", "445,3389,5900,1433,5432,27017,11211,1883"),
}


async def run() -> None:
    logging.basicConfig(level=env("HN_LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    log_dir, state_dir = env("HN_LOG_DIR", "/data/logs"), env("HN_STATE_DIR", "/data/state")
    sensor = env("HN_SENSOR", socket.gethostname())
    bind = env("HN_BIND", "0.0.0.0")
    wanted = [x.strip() for x in env("HN_SERVICES", "ssh,telnet,http,https,ftp,smtp,redis,mysql,tcp").split(",") if x.strip()]
    limiter = Limiter(env_int("HN_MAX_CONNECTIONS", 500), env_int("HN_MAX_PER_IP", 20))

    loggers: dict[str, EventLogger] = {}
    instances: dict[str, object] = {}
    started: list[tuple[str, int]] = []
    for name in wanted:
        if name not in REGISTRY:
            logging.error("unknown service %r (valid: %s)", name, ", ".join(REGISTRY))
            continue
        cls, logname, port_env, default_ports = REGISTRY[name]
        lg = loggers.setdefault(logname, EventLogger(logname, log_dir, sensor))
        # http + https share one instance (same log file)
        key = logname if logname == "http" else name
        svc = instances.get(key)
        if svc is None:
            svc = cls(lg, limiter, {"key_dir": os.path.join(state_dir, "keys")}) if name == "ssh" else cls(lg, limiter)
            instances[key] = svc
        ssl_ctx = make_ssl_context(state_dir) if name == "https" else None
        for port in parse_ports(env(port_env, default_ports)):
            try:
                await svc.start(bind, port, ssl_ctx)  # type: ignore[attr-defined]
                started.append((name, port))
                logging.info("listening: %s on %s:%d", name, bind, port)
            except OSError as e:
                logging.error("cannot bind %s port %d: %s", name, port, e)

    if not started:
        raise SystemExit("no honeypot service could start")

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    while not stop.is_set():
        try:
            with open(READY_FILE, "w") as f:
                f.write(str(time.time()))
        except OSError:
            pass
        try:
            await asyncio.wait_for(stop.wait(), 15)
        except asyncio.TimeoutError:
            pass
    logging.info("shutting down")
    for svc in instances.values():
        await svc.stop()  # type: ignore[attr-defined]


def main() -> None:
    asyncio.run(run())


if __name__ == "__main__":
    main()
