"""Redis and MySQL honeypots."""
from __future__ import annotations

import os
import struct

from .common import Service, Session

MAX_BULK = 1024 * 1024
MAX_ARGS = 256

REDIS_INFO = (
    "# Server\r\nredis_version:5.0.7\r\nredis_mode:standalone\r\nos:Linux 5.10.0-21-amd64 x86_64\r\n"
    "arch_bits:64\r\ntcp_port:6379\r\nuptime_in_seconds:3600211\r\n"
    "# Clients\r\nconnected_clients:1\r\n# Memory\r\nused_memory_human:1.02M\r\n"
    "# Keyspace\r\ndb0:keys=0,expires=0,avg_ttl=0\r\n"
)
REDIS_SUSPICIOUS = {"config", "slaveof", "replicaof", "module", "eval", "evalsha", "script", "save", "bgsave",
                    "flushall", "flushdb", "debug", "shutdown", "migrate", "psync"}


class RedisService(Service):
    name = "redis"

    async def _read_command(self, s: Session) -> list[bytes] | None:
        line = await s.readline(4096)
        if not line:
            return None
        line = line.rstrip(b"\r\n")
        if not line.startswith(b"*"):
            return line.split() or [b""]  # inline command
        try:
            n = int(line[1:])
        except ValueError:
            return [line]
        if n < 0 or n > MAX_ARGS:
            return None
        args: list[bytes] = []
        for _ in range(n):
            hdr = (await s.readline(64)).rstrip(b"\r\n")
            if not hdr.startswith(b"$"):
                return args or None
            try:
                ln = int(hdr[1:])
            except ValueError:
                return args or None
            if ln < 0 or ln > MAX_BULK:
                return None
            data = await s.readexactly(ln + 2)
            args.append(data[:-2])
        return args

    async def handle(self, s: Session) -> None:
        for _ in range(500):
            args = await self._read_command(s)
            if args is None:
                return
            if not args or not args[0]:
                continue
            cmd = args[0].decode("utf-8", "replace").lower()
            rest = [a.decode("utf-8", "replace") for a in args[1:]]
            tags = ["redis_" + cmd] if cmd in REDIS_SUSPICIOUS else []
            s.log("command", command=" ".join([cmd] + rest)[:2048], cmd=cmd, args=rest[:16], tags=tags)
            if cmd == "auth":
                s.log("auth", username="", password=rest[-1] if rest else "", success=False, method="redis")
            await s.send(self._reply(cmd, rest))
            if cmd == "quit":
                return

    def _reply(self, cmd: str, a: list[str]) -> bytes:
        if cmd == "ping":
            return b"+PONG\r\n"
        if cmd == "quit":
            return b"+OK\r\n"
        if cmd == "info":
            return b"$%d\r\n%s\r\n" % (len(REDIS_INFO), REDIS_INFO.encode())
        if cmd == "auth":
            return b"-ERR Client sent AUTH, but no password is set\r\n"
        if cmd == "config" and a and a[0].lower() == "get":
            key = a[1] if len(a) > 1 else "*"
            val = {"dir": "/var/lib/redis", "dbfilename": "dump.rdb"}.get(key, "")
            if not val:
                return b"*0\r\n"
            return b"*2\r\n$%d\r\n%s\r\n$%d\r\n%s\r\n" % (len(key), key.encode(), len(val), val.encode())
        if cmd in ("keys", "command", "scan", "smembers", "lrange", "hgetall"):
            return b"*0\r\n"
        if cmd in ("get", "hget"):
            return b"$-1\r\n"
        if cmd in ("dbsize", "del", "exists", "incr", "ttl"):
            return b":0\r\n"
        if cmd in ("set", "setex", "flushall", "flushdb", "save", "bgsave", "slaveof", "replicaof",
                   "select", "client", "config", "hset", "lpush", "rpush", "sadd", "expire", "debug"):
            return b"+OK\r\n"
        if cmd in ("eval", "evalsha", "module", "script", "migrate", "shutdown"):
            return b"-ERR operation not permitted\r\n"
        return b"-ERR unknown command '%s'\r\n" % cmd.encode()[:64]


def _pkt(seq: int, payload: bytes) -> bytes:
    return struct.pack("<I", len(payload))[:3] + bytes([seq]) + payload


class MySQLService(Service):
    name = "mysql"
    VERSION = b"5.7.38-0ubuntu0.18.04.1-log"

    async def handle(self, s: Session) -> None:
        salt = os.urandom(20)
        # Handshake V10. Capabilities exclude CLIENT_SSL so clients stay in plaintext.
        hs = (b"\x0a" + self.VERSION + b"\x00" + struct.pack("<I", int.from_bytes(os.urandom(2), "big") + 1000)
              + salt[:8] + b"\x00" + struct.pack("<H", 0xF7FF) + b"\x21" + struct.pack("<H", 0x0002)
              + struct.pack("<H", 0x807F) + b"\x15" + b"\x00" * 10 + salt[8:] + b"\x00"
              + b"mysql_native_password\x00")
        await s.send(_pkt(0, hs))
        hdr = await s.readexactly(4)
        if len(hdr) < 4:
            return
        ln = int.from_bytes(hdr[:3], "little")
        if ln > 65536 or ln < 4:
            s.log("raw_request", kind="bad_mysql_packet", hex=hdr.hex())
            return
        body = await s.readexactly(ln)
        user, auth, db, caps = self._parse(body)
        s.log("auth", username=user, password="", success=False, method="mysql_native",
              auth_response=auth.hex(), salt=salt.hex(), database=db, client_caps=hex(caps))
        msg = f"Access denied for user '{user}'@'{s.ip}' (using password: {'YES' if auth else 'NO'})"
        err = b"\xff" + struct.pack("<H", 1045) + b"#28000" + msg.encode("utf-8", "replace")
        await s.send(_pkt(hdr[3] + 1 if len(hdr) > 3 else 2, err))

    @staticmethod
    def _parse(b: bytes) -> tuple[str, bytes, str, int]:
        try:
            caps = struct.unpack("<I", b[:4])[0]
            i = 4 + 4 + 1 + 23
            end = b.index(b"\x00", i)
            user = b[i:end].decode("utf-8", "replace")
            i = end + 1
            if caps & 0x00200000:  # PLUGIN_AUTH_LENENC_CLIENT_DATA
                n = b[i]
                i += 1
            elif caps & 0x8000:  # SECURE_CONNECTION
                n = b[i]
                i += 1
            else:
                n = 0
            auth = b[i:i + n]
            i += n
            db = ""
            if caps & 0x8 and i < len(b):
                db = b[i:b.index(b"\x00", i)].decode("utf-8", "replace") if b"\x00" in b[i:] else ""
            return user, auth, db, caps
        except (ValueError, IndexError, struct.error):
            return "", b"", "", 0
