"""Generic TCP catch-all: records the first bytes sent to otherwise-unserved ports
(RDP, SMB, VNC, MSSQL, Postgres, MongoDB, Memcached, MQTT ...) and fingerprints the protocol."""
from __future__ import annotations

from .common import Service, Session, printable

BANNERS = {5900: b"RFB 003.008\n"}

SIGNATURES = [
    (b"\x16\x03", "tls_clienthello"), (b"\x03\x00", "rdp_x224"), (b"\xffSMB", "smb1"),
    (b"\xfeSMB", "smb2"), (b"\x00\x00\x00", "smb_netbios_or_tds"), (b"RFB ", "vnc"),
    (b"GET ", "http"), (b"POST ", "http"), (b"CONNECT ", "http_proxy"), (b"SSH-", "ssh"),
    (b"\x05\x01", "socks5"), (b"\x04\x01", "socks4"), (b"stats", "memcached"), (b"\x10", "mqtt_connect"),
    (b"\x12\x01", "tds_prelogin"), (b"\x00\x00\x00\x08\x04\xd2\x16\x2f", "postgres_sslrequest"),
]


def fingerprint(data: bytes) -> str:
    for sig, name in SIGNATURES:
        if data.startswith(sig):
            return name
    return "unknown"


class TCPCatchAll(Service):
    name = "tcp"

    async def handle(self, s: Session) -> None:
        banner = BANNERS.get(s.dport)
        if banner:
            await s.send(banner)
        data = await s.read(2048, timeout=10)
        if data:
            s.log("payload", protocol=fingerprint(data), hex=data[:256].hex(), text=printable(data, 256), size=len(data))
            more = await s.read(2048, timeout=3)
            if more:
                s.log("payload", protocol=fingerprint(more), hex=more[:256].hex(), text=printable(more, 256), size=len(more))
