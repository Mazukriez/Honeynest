"""Shared plumbing for every Honeynest honeypot service.

Design rules (security first):
  * Nothing an attacker sends is ever executed or fetched.
  * Every connection is bounded: total + per-IP limits, byte caps, timeouts.
  * Every event is one JSON line (JSONL) so any collector can consume it.
"""
from __future__ import annotations

import asyncio
import json
import logging
import logging.handlers
import os
import socket
import sys
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable

MAX_FIELD = 4096  # max characters stored for any single logged string


def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def env_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def clip(value: Any, limit: int = MAX_FIELD) -> Any:
    """Make a value JSON-safe and bounded in size."""
    if isinstance(value, (bytes, bytearray)):
        value = bytes(value).decode("utf-8", "backslashreplace")
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + f"...[+{len(value) - limit}]"
    if isinstance(value, dict):
        return {str(k)[:128]: clip(v, limit) for k, v in list(value.items())[:100]}
    if isinstance(value, (list, tuple, set)):
        return [clip(v, limit) for v in list(value)[:100]]
    return value


class EventLogger:
    """Writes events to a rotating JSONL file and to stdout."""

    def __init__(self, service: str, log_dir: str, sensor: str,
                 max_bytes: int = 50 * 1024 * 1024, backups: int = 5,
                 echo: bool = True):
        self.service = service
        self.sensor = sensor
        self._echo = echo
        self._lg = logging.getLogger(f"hn.events.{service}")
        self._lg.setLevel(logging.INFO)
        self._lg.propagate = False
        self._lg.handlers.clear()
        os.makedirs(log_dir, exist_ok=True)
        h = logging.handlers.RotatingFileHandler(
            os.path.join(log_dir, f"{service}.jsonl"),
            maxBytes=max_bytes, backupCount=backups, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(message)s"))
        self._lg.addHandler(h)

    def emit(self, event: str, src_ip: str = "", src_port: int | None = None,
             dst_port: int | None = None, session: str | None = None, **data: Any) -> dict:
        rec = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "sensor": self.sensor,
            "service": self.service,
            "event": event,
            "src_ip": src_ip,
            "src_port": src_port,
            "dst_port": dst_port,
            "session": session,
            "data": clip(data),
        }
        line = json.dumps(rec, ensure_ascii=True, separators=(",", ":"))
        self._lg.info(line)
        if self._echo:
            print(line, file=sys.stdout, flush=True)
        return rec


class Limiter:
    """Caps concurrent connections globally and per source IP."""

    def __init__(self, max_total: int = 500, max_per_ip: int = 20):
        self.max_total = max_total
        self.max_per_ip = max_per_ip
        self.total = 0
        self.per_ip: dict[str, int] = {}

    def acquire(self, ip: str) -> bool:
        if self.total >= self.max_total or self.per_ip.get(ip, 0) >= self.max_per_ip:
            return False
        self.total += 1
        self.per_ip[ip] = self.per_ip.get(ip, 0) + 1
        return True

    def release(self, ip: str) -> None:
        self.total = max(0, self.total - 1)
        n = self.per_ip.get(ip, 0) - 1
        if n <= 0:
            self.per_ip.pop(ip, None)
        else:
            self.per_ip[ip] = n


class Session:
    """One attacker connection."""

    def __init__(self, svc: "Service", reader: asyncio.StreamReader,
                 writer: asyncio.StreamWriter):
        peer = writer.get_extra_info("peername") or ("?", 0)
        sock = writer.get_extra_info("sockname") or ("?", 0)
        self.svc = svc
        self.reader = reader
        self.writer = writer
        self.ip = _clean_ip(str(peer[0]))
        self.port = int(peer[1]) if len(peer) > 1 else 0
        self.dport = int(sock[1]) if len(sock) > 1 else 0
        self.id = uuid.uuid4().hex[:12]
        self.start = time.monotonic()
        self.bytes_in = 0
        self.bytes_out = 0

    def log(self, event: str, **data: Any) -> None:
        self.svc.log.emit(event, self.ip, self.port, self.dport, self.id, **data)

    async def send(self, data: bytes | str) -> None:
        if isinstance(data, str):
            data = data.encode("utf-8", "replace")
        self.bytes_out += len(data)
        self.writer.write(data)
        await self.writer.drain()

    async def readline(self, limit: int = 4096, timeout: float | None = None) -> bytes:
        """Read one line (bounded). Returns b'' on EOF/timeout."""
        timeout = timeout or self.svc.idle_timeout
        try:
            line = await asyncio.wait_for(self.reader.readuntil(b"\n"), timeout)
        except asyncio.IncompleteReadError as e:
            line = e.partial
        except asyncio.LimitOverrunError:
            line = await self.reader.read(limit)
            self.bytes_in += len(line)
            return line[:limit]
        except (asyncio.TimeoutError, ConnectionError):
            return b""
        self.bytes_in += len(line)
        return line[:limit]

    async def read(self, n: int, timeout: float | None = None) -> bytes:
        try:
            data = await asyncio.wait_for(self.reader.read(n), timeout or self.svc.idle_timeout)
        except (asyncio.TimeoutError, ConnectionError):
            return b""
        self.bytes_in += len(data)
        return data

    async def readexactly(self, n: int, timeout: float | None = None) -> bytes:
        try:
            data = await asyncio.wait_for(self.reader.readexactly(n), timeout or self.svc.idle_timeout)
        except asyncio.IncompleteReadError as e:
            data = e.partial
        except (asyncio.TimeoutError, ConnectionError):
            return b""
        self.bytes_in += len(data)
        return data


def _clean_ip(ip: str) -> str:
    # ::ffff:1.2.3.4 -> 1.2.3.4 ; strip scope id
    ip = ip.split("%")[0]
    if ip.lower().startswith("::ffff:") and "." in ip:
        return ip[7:]
    return ip


class Service:
    """Base class for every honeypot service."""

    name = "base"

    def __init__(self, log: EventLogger, limiter: Limiter, cfg: dict[str, Any] | None = None):
        self.log = log
        self.limiter = limiter
        self.cfg = cfg or {}
        self.idle_timeout = env_int("HN_IDLE_TIMEOUT", 60)
        self.session_timeout = env_int("HN_SESSION_TIMEOUT", 300)
        self.servers: list[asyncio.base_events.Server] = []

    async def handle(self, sess: Session) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    async def _wrap(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        sess = Session(self, reader, writer)
        if not self.limiter.acquire(sess.ip):
            sess.log("limit_exceeded")
            _close(writer)
            return
        sess.log("connect")
        err = None
        try:
            await asyncio.wait_for(self.handle(sess), self.session_timeout)
        except asyncio.TimeoutError:
            err = "session_timeout"
        except (ConnectionError, asyncio.IncompleteReadError, OSError):
            err = "connection_error"
        except Exception as e:  # never let one attacker kill the service
            err = f"internal:{type(e).__name__}"
            logging.getLogger("hn").exception("handler error in %s", self.name)
        finally:
            self.limiter.release(sess.ip)
            sess.log("disconnect", duration=round(time.monotonic() - sess.start, 2),
                     bytes_in=sess.bytes_in, bytes_out=sess.bytes_out, **({"reason": err} if err else {}))
            _close(writer)

    async def start(self, host: str, port: int, ssl: Any = None) -> None:
        srv = await asyncio.start_server(self._wrap, host, port, ssl=ssl, limit=65536,
                                         reuse_address=True, backlog=256)
        self.servers.append(srv)

    async def stop(self) -> None:
        for s in self.servers:
            s.close()
        for s in self.servers:
            try:
                await asyncio.wait_for(s.wait_closed(), 3)
            except Exception:
                pass


def _close(writer: asyncio.StreamWriter) -> None:
    try:
        writer.close()
    except Exception:
        pass


def parse_ports(value: str) -> list[int]:
    ports = []
    for part in value.split(","):
        part = part.strip()
        if part.isdigit() and 0 < int(part) < 65536:
            ports.append(int(part))
    return ports


def printable(data: bytes, limit: int = 512) -> str:
    return "".join(chr(b) if 32 <= b < 127 else "." for b in data[:limit])


Handler = Callable[[Session], Awaitable[None]]
_ = socket  # (kept for type checkers)
