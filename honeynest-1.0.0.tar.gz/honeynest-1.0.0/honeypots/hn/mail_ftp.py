"""FTP and SMTP honeypots. Credentials and mail are captured, never relayed or stored on disk."""
from __future__ import annotations

import base64
import binascii

from .common import Service, Session, env, env_int

SMTP_MAX_DATA = 64 * 1024


class FTPService(Service):
    name = "ftp"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.banner = env("HN_FTP_BANNER", "220 (vsFTPd 3.0.3)")
        self.accept_after = env_int("HN_FTP_ACCEPT_AFTER", 2)
        self.attempts: dict[str, int] = {}

    async def handle(self, s: Session) -> None:
        await s.send(self.banner + "\r\n")
        user = None
        authed = False
        for _ in range(100):
            raw = await s.readline(1024)
            if not raw:
                return
            line = raw.decode("utf-8", "replace").strip()
            cmd, _, arg = line.partition(" ")
            cmd = cmd.upper()
            if cmd == "USER":
                user = arg
                await s.send("331 Please specify the password.\r\n")
            elif cmd == "PASS":
                n = self.attempts.get(s.ip, 0) + 1
                self.attempts[s.ip] = n
                authed = bool(user) and n >= self.accept_after
                s.log("auth", username=user or "", password=arg, success=authed, method="ftp")
                if authed:
                    s.log("login_success", username=user, password=arg)
                    await s.send("230 Login successful.\r\n")
                else:
                    await s.send("530 Login incorrect.\r\n")
            elif cmd == "QUIT":
                await s.send("221 Goodbye.\r\n")
                return
            elif cmd in ("SYST",):
                await s.send("215 UNIX Type: L8\r\n")
            elif cmd == "FEAT":
                await s.send("211-Features:\r\n PASV\r\n UTF8\r\n211 End\r\n")
            elif not authed:
                s.log("command", command=line)
                await s.send("530 Please login with USER and PASS.\r\n")
            else:
                s.log("command", command=line)
                if cmd == "PWD":
                    await s.send('257 "/" is the current directory\r\n')
                elif cmd in ("TYPE", "CWD", "CDUP", "NOOP", "MODE", "STRU"):
                    await s.send("200 OK.\r\n")
                elif cmd in ("PASV", "EPSV", "PORT", "EPRT", "LIST", "NLST", "RETR", "STOR", "APPE"):
                    await s.send("425 Can't open data connection.\r\n")
                else:
                    await s.send("502 Command not implemented.\r\n")


class SMTPService(Service):
    name = "smtp"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.hostname = env("HN_SMTP_HOSTNAME", "mail.acme-corp.example")

    async def handle(self, s: Session) -> None:
        await s.send(f"220 {self.hostname} ESMTP Postfix (Ubuntu)\r\n")
        mail_from, rcpts = "", []
        for _ in range(100):
            raw = await s.readline(1024)
            if not raw:
                return
            line = raw.decode("utf-8", "replace").strip()
            up = line.upper()
            if up.startswith(("EHLO", "HELO")):
                s.log("hello", helo=line[5:])
                await s.send(f"250-{self.hostname}\r\n250-PIPELINING\r\n250-SIZE 10240000\r\n"
                             "250-AUTH LOGIN PLAIN\r\n250 8BITMIME\r\n")
            elif up.startswith("AUTH"):
                await self._auth(s, line)
            elif up.startswith("MAIL FROM"):
                mail_from = line[10:].strip()
                await s.send("250 2.1.0 Ok\r\n")
            elif up.startswith("RCPT TO"):
                rcpts.append(line[8:].strip())
                await s.send("250 2.1.5 Ok\r\n")
            elif up == "DATA":
                await s.send("354 End data with <CR><LF>.<CR><LF>\r\n")
                data = await self._data(s)
                s.log("mail", mail_from=mail_from, rcpt_to=rcpts, size=len(data), body=data[:2048])
                await s.send("250 2.0.0 Ok: queued as 4F3A1C2B9D\r\n")
                mail_from, rcpts = "", []
            elif up == "QUIT":
                await s.send("221 2.0.0 Bye\r\n")
                return
            elif up in ("RSET", "NOOP"):
                await s.send("250 2.0.0 Ok\r\n")
            elif up.startswith("STARTTLS"):
                await s.send("454 4.7.0 TLS not available due to local problem\r\n")
            else:
                s.log("command", command=line)
                await s.send("502 5.5.2 Error: command not recognized\r\n")

    async def _data(self, s: Session) -> str:
        buf = bytearray()
        while len(buf) < SMTP_MAX_DATA:
            raw = await s.readline(4096)
            if not raw or raw.strip() == b".":
                break
            buf += raw
        return bytes(buf).decode("utf-8", "replace")

    async def _auth(self, s: Session, line: str) -> None:
        parts = line.split()
        mech = parts[1].upper() if len(parts) > 1 else ""

        def dec(b: str) -> str:
            try:
                return base64.b64decode(b, validate=False).decode("utf-8", "replace")
            except (binascii.Error, ValueError):
                return b

        user = pw = ""
        if mech == "PLAIN":
            if len(parts) > 2:
                blob = parts[2]
            else:
                await s.send("334 \r\n")
                blob = (await s.readline(1024)).decode().strip()
            f = dec(blob).split("\x00")
            user, pw = (f[-2] if len(f) >= 2 else ""), (f[-1] if f else "")
        elif mech == "LOGIN":
            if len(parts) > 2:
                user = dec(parts[2])
            else:
                await s.send("334 VXNlcm5hbWU6\r\n")
                user = dec((await s.readline(1024)).decode().strip())
            await s.send("334 UGFzc3dvcmQ6\r\n")
            pw = dec((await s.readline(1024)).decode().strip())
        else:
            await s.send("504 5.5.4 Unrecognized authentication type\r\n")
            return
        s.log("auth", username=user, password=pw, success=False, method=f"smtp_{mech.lower()}")
        await s.send("535 5.7.8 Error: authentication failed\r\n")
