"""A fake Linux shell used by the SSH and Telnet honeypots.

SAFETY: this module NEVER executes anything, never touches the real filesystem
and never opens a network connection. It only emulates plausible output and
records what the attacker tried (commands, URLs, written files).
"""
from __future__ import annotations

import posixpath
import re
import shlex
from typing import Callable

URL_RE = re.compile(r"\b(?:https?|ftp|tftp)://[^\s'\"<>|;&]+", re.I)
SPLIT_RE = re.compile(r"\s*(?:;|&&|\|\||\n)\s*")

PASSWD = (
    "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n"
    "bin:x:2:2:bin:/bin:/usr/sbin/nologin\nsys:x:3:3:sys:/dev:/usr/sbin/nologin\n"
    "www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin\n"
    "sshd:x:105:65534::/run/sshd:/usr/sbin/nologin\nubuntu:x:1000:1000:Ubuntu:/home/ubuntu:/bin/bash\n"
)
OS_RELEASE = (
    'PRETTY_NAME="Debian GNU/Linux 11 (bullseye)"\nNAME="Debian GNU/Linux"\nVERSION_ID="11"\n'
    'VERSION="11 (bullseye)"\nID=debian\n'
)
CPUINFO = (
    "processor\t: 0\nvendor_id\t: GenuineIntel\ncpu family\t: 6\nmodel\t\t: 85\n"
    "model name\t: Intel(R) Xeon(R) Platinum 8175M CPU @ 2.50GHz\ncpu MHz\t\t: 2499.998\n"
    "cache size\t: 33792 KB\ncpu cores\t: 2\n"
)


def _default_fs() -> tuple[dict[str, str], set[str]]:
    files = {
        "/etc/passwd": PASSWD,
        "/etc/shadow": "",  # permission denied
        "/etc/hostname": "web-prod-02\n",
        "/etc/os-release": OS_RELEASE,
        "/etc/issue": "Debian GNU/Linux 11 \\n \\l\n",
        "/proc/cpuinfo": CPUINFO,
        "/proc/version": "Linux version 5.10.0-21-amd64 (debian-kernel@lists.debian.org) "
                         "(gcc-10 (Debian 10.2.1-6) 10.2.1 20210110) #1 SMP Debian 5.10.162-1\n",
        "/proc/meminfo": "MemTotal:        4028164 kB\nMemFree:         1203452 kB\n",
        "/root/.bash_history": "ls\ncd /var/www\nsystemctl restart nginx\n",
        "/root/notes.txt": "TODO: rotate backup keys\n",
        "/var/www/html/index.html": "<html><body>It works!</body></html>\n",
    }
    dirs = {"/", "/etc", "/root", "/home", "/home/ubuntu", "/tmp", "/var", "/var/www",
            "/var/www/html", "/var/log", "/usr", "/usr/bin", "/bin", "/proc", "/dev", "/opt", "/mnt"}
    return files, dirs


class FakeShell:
    def __init__(self, user: str = "root", hostname: str = "web-prod-02",
                 on_event: Callable[..., None] | None = None):
        self.user = user
        self.hostname = hostname
        self.on_event = on_event or (lambda *a, **k: None)
        self.files, self.dirs = _default_fs()
        self.cwd = "/root" if user == "root" else f"/home/{user}"
        self.dirs.add(self.cwd)
        self.downloaded: set[str] = set()
        self.history: list[str] = []
        self.exited = False
        self.env = {"HOME": self.cwd, "USER": user, "SHELL": "/bin/bash",
                    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                    "LANG": "en_US.UTF-8", "PWD": self.cwd}
        self.cmds: dict[str, Callable[[list[str]], str]] = {
            "pwd": lambda a: self.cwd + "\n", "whoami": lambda a: self.user + "\n",
            "id": self._id, "hostname": lambda a: self.hostname + "\n", "uname": self._uname,
            "ls": self._ls, "cd": self._cd, "cat": self._cat, "echo": self._echo,
            "ps": self._ps, "uptime": lambda a: " 11:42:07 up 41 days,  3:12,  1 user,  load average: 0.08, 0.03, 0.01\n",
            "w": lambda a: " 11:42:07 up 41 days,  3:12,  1 user,  load average: 0.08, 0.03, 0.01\n"
                           "USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT\n"
                           f"{self.user}  pts/0    10.0.0.5         11:41    0.00s  0.02s  0.00s w\n",
            "who": lambda a: f"{self.user}  pts/0        2026-10-11 11:41 (10.0.0.5)\n",
            "free": self._free, "df": self._df, "ifconfig": self._ifconfig, "ip": self._ifconfig,
            "env": lambda a: "".join(f"{k}={v}\n" for k, v in self.env.items()),
            "printenv": lambda a: "".join(f"{k}={v}\n" for k, v in self.env.items()),
            "history": lambda a: "".join(f"{i + 1:5d}  {h}\n" for i, h in enumerate(self.history)),
            "mkdir": self._mkdir, "touch": self._touch, "rm": self._rm, "chmod": lambda a: "",
            "chown": lambda a: "", "export": self._export, "unset": lambda a: "",
            "wget": self._download, "curl": self._download, "tftp": self._download,
            "ftpget": self._download, "busybox": self._busybox, "sudo": self._sudo,
            "su": lambda a: "", "exit": self._exit, "logout": self._exit, "clear": lambda a: "\x1b[H\x1b[2J",
            "nproc": lambda a: "2\n", "lscpu": lambda a: CPUINFO, "sleep": lambda a: "",
            "true": lambda a: "", "false": lambda a: "", "kill": lambda a: "", "killall": lambda a: "",
            "pkill": lambda a: "", "nohup": lambda a: "", "crontab": lambda a: "no crontab for " + self.user + "\n",
            "passwd": lambda a: "passwd: password updated successfully\n", "set": lambda a: "",
            "netstat": lambda a: "Active Internet connections (servers and established)\n"
                                 "Proto Recv-Q Send-Q Local Address           Foreign Address         State\n"
                                 "tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN\n",
            "ss": lambda a: "State   Recv-Q  Send-Q   Local Address:Port   Peer Address:Port\nLISTEN  0       128            0.0.0.0:22          0.0.0.0:*\n",
            "apt": lambda a: "", "apt-get": lambda a: "", "yum": lambda a: "", "dpkg": lambda a: "",
            "systemctl": lambda a: "", "service": lambda a: "", "type": lambda a: "", "which": self._which,
            "lsb_release": lambda a: "Distributor ID:\tDebian\nDescription:\tDebian GNU/Linux 11 (bullseye)\nRelease:\t11\nCodename:\tbullseye\n",
        }

    # ---------- public API ----------
    @property
    def prompt(self) -> str:
        sym = "#" if self.user == "root" else "$"
        cwd = "~" if self.cwd == self.env["HOME"] else self.cwd
        return f"{self.user}@{self.hostname}:{cwd}{sym} "

    def run(self, line: str) -> str:
        line = line.strip("\r\n ")
        if not line:
            return ""
        self.history.append(line)
        self._scan_urls(line, "command")
        out: list[str] = []
        # pipes into a shell are the classic "curl | sh" dropper
        if re.search(r"\|\s*(?:ba)?sh\b", line):
            self.on_event("pipe_to_shell", command=line)
        for part in SPLIT_RE.split(line):
            if not part:
                continue
            first = re.split(r"\s*\|\s*", part)[0]
            out.append(self._run_one(first))
            if self.exited:
                break
        return "".join(out)

    # ---------- internals ----------
    def _scan_urls(self, text: str, source: str) -> None:
        for url in dict.fromkeys(URL_RE.findall(text)):  # de-duplicated, order kept
            self.on_event("download_attempt", url=url, source=source)

    def _run_one(self, part: str) -> str:
        redirect = None
        m = re.search(r"(>>?)\s*(\S+)\s*$", part)
        if m and not part.lstrip().startswith(("wget", "curl")):
            redirect, part = (m.group(1), m.group(2)), part[:m.start()]
        try:
            argv = shlex.split(part)
        except ValueError:
            argv = part.split()
        while argv and re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", argv[0]):  # VAR=val cmd
            k, _, v = argv.pop(0).partition("=")
            self.env[k] = v
        if not argv:
            return ""
        name = posixpath.basename(argv[0])
        if argv[0].startswith(("./", "/tmp/", "/var/tmp/", "/dev/shm/")) and self._abs(argv[0]) in self.files:
            return ""  # "executing" a dropped binary: silently does nothing
        fn = self.cmds.get(name)
        if fn is None:
            return f"-bash: {argv[0]}: command not found\n"
        out = fn(argv[1:])
        if redirect:
            path = self._abs(redirect[1])
            prev = self.files.get(path, "") if redirect[0] == ">>" else ""
            self.files[path] = prev + out
            self.on_event("file_write", path=path, content=out[:512])
            return ""
        return out

    def _abs(self, p: str) -> str:
        if p == "~" or p.startswith("~/"):
            p = self.env["HOME"] + p[1:]
        return posixpath.normpath(p if p.startswith("/") else posixpath.join(self.cwd, p))

    def _id(self, a: list[str]) -> str:
        if self.user == "root":
            return "uid=0(root) gid=0(root) groups=0(root)\n"
        return f"uid=1000({self.user}) gid=1000({self.user}) groups=1000({self.user}),27(sudo)\n"

    def _uname(self, a: list[str]) -> str:
        flags = "".join(a)
        if "a" in flags:
            return "Linux web-prod-02 5.10.0-21-amd64 #1 SMP Debian 5.10.162-1 (2023-01-21) x86_64 GNU/Linux\n"
        if "m" in flags:
            return "x86_64\n"
        if "r" in flags:
            return "5.10.0-21-amd64\n"
        return "Linux\n"

    def _ls(self, a: list[str]) -> str:
        flags = "".join(x[1:] for x in a if x.startswith("-"))
        targets = [x for x in a if not x.startswith("-")] or ["."]
        out = []
        for t in targets:
            p = self._abs(t)
            if p in self.files:
                names = [posixpath.basename(p)]
            elif p in self.dirs:
                names = sorted({q.split("/")[len(p.rstrip("/").split("/"))]
                                for q in list(self.files) + list(self.dirs)
                                if q != p and q.startswith(p.rstrip("/") + "/")})
                if "a" in flags:
                    names = [".", ".."] + names
                else:
                    names = [n for n in names if not n.startswith(".")]
            else:
                out.append(f"ls: cannot access '{t}': No such file or directory\n")
                continue
            if "l" in flags:
                out.append(f"total {len(names) * 4}\n")
                for n in names:
                    full = posixpath.join(p, n)
                    isd = full in self.dirs or n in (".", "..")
                    size = len(self.files.get(full, "")) if not isd else 4096
                    out.append(f"{'d' if isd else '-'}rwxr-xr-x 2 root root {size:>6} Sep 14 09:12 {n}\n")
            else:
                out.append("  ".join(names) + "\n" if names else "")
        return "".join(out)

    def _cd(self, a: list[str]) -> str:
        p = self._abs(a[0] if a else "~")
        if p in self.dirs:
            self.cwd = p
            return ""
        return f"-bash: cd: {a[0] if a else p}: No such file or directory\n"

    def _cat(self, a: list[str]) -> str:
        out = []
        for t in [x for x in a if not x.startswith("-")]:
            p = self._abs(t)
            if p == "/etc/shadow":
                out.append("cat: /etc/shadow: Permission denied\n")
            elif p in self.files:
                out.append(self.files[p])
            elif p in self.dirs:
                out.append(f"cat: {t}: Is a directory\n")
            else:
                out.append(f"cat: {t}: No such file or directory\n")
        return "".join(out)

    def _echo(self, a: list[str]) -> str:
        interpret = bool(a and a[0] == "-e")
        nonl = bool(a and a[0] in ("-n", "-ne", "-en"))
        txt = " ".join(a[1:] if (interpret or nonl) else a)
        for k, v in self.env.items():
            txt = txt.replace("$" + k, v)
        if interpret:
            txt = txt.encode().decode("unicode_escape", "ignore")
        return txt + ("" if nonl else "\n")

    def _ps(self, a: list[str]) -> str:
        return ("  PID TTY          TIME CMD\n    1 ?        00:00:03 systemd\n  412 ?        00:00:00 sshd\n"
                " 1311 pts/0    00:00:00 bash\n 1402 pts/0    00:00:00 ps\n"
                if not a else
                "USER       PID %CPU %MEM COMMAND\nroot         1  0.0  0.1 /sbin/init\nroot       412  0.0  0.2 /usr/sbin/sshd -D\n"
                f"{self.user}      1311  0.0  0.1 -bash\n")

    def _free(self, a: list[str]) -> str:
        return ("              total        used        free      shared  buff/cache   available\n"
                "Mem:        4028164     1021340     1203452       10412     1803372     2790108\n"
                "Swap:             0           0           0\n")

    def _df(self, a: list[str]) -> str:
        return ("Filesystem     1K-blocks    Used Available Use% Mounted on\n"
                "/dev/sda1       41152812 9872144  29174532  26% /\ntmpfs            2014080       0   2014080   0% /dev/shm\n")

    def _ifconfig(self, a: list[str]) -> str:
        return ("eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\n"
                "        inet 10.0.2.15  netmask 255.255.255.0  broadcast 10.0.2.255\n"
                "        ether 52:54:00:12:34:56  txqueuelen 1000  (Ethernet)\n"
                "lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536\n        inet 127.0.0.1  netmask 255.0.0.0\n")

    def _mkdir(self, a: list[str]) -> str:
        for t in [x for x in a if not x.startswith("-")]:
            self.dirs.add(self._abs(t))
        return ""

    def _touch(self, a: list[str]) -> str:
        for t in a:
            self.files.setdefault(self._abs(t), "")
        return ""

    def _rm(self, a: list[str]) -> str:
        for t in [x for x in a if not x.startswith("-")]:
            p = self._abs(t)
            self.files.pop(p, None)
            self.downloaded.discard(p)
        return ""

    def _export(self, a: list[str]) -> str:
        for x in a:
            k, _, v = x.partition("=")
            self.env[k] = v
        return ""

    def _download(self, a: list[str]) -> str:
        """Pretend to download; we never touch the network."""
        urls = [x for x in a if URL_RE.match(x)]  # URLs are already logged by run() -> _scan_urls
        name = None
        for i, x in enumerate(a):
            if x in ("-O", "-o") and i + 1 < len(a):
                name = a[i + 1]
        if urls and name is None:
            name = posixpath.basename(urls[0].split("?")[0]) or "index.html"
        if name and name != "-":
            p = self._abs(name)
            self.files[p] = ""
            self.downloaded.add(p)
        if urls and a and a[0:1] != ["-s"]:
            return f"Saving to: '{name}'\n\n{name}  100%[===================>]  12.34K  --.-KB/s    in 0s\n"
        return ""

    def _busybox(self, a: list[str]) -> str:
        if not a:
            return "BusyBox v1.30.1 (Debian 1:1.30.1-6+b3) multi-call binary.\n"
        fn = self.cmds.get(a[0])
        return fn(a[1:]) if fn else f"{a[0]}: applet not found\n"

    def _sudo(self, a: list[str]) -> str:
        a = [x for x in a if not x.startswith("-")]
        return self._run_one(" ".join(a)) if a else ""

    def _which(self, a: list[str]) -> str:
        return "".join(f"/usr/bin/{x}\n" for x in a if x in self.cmds)

    def _exit(self, a: list[str]) -> str:
        self.exited = True
        return "logout\n"
