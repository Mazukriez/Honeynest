"""HTTP/HTTPS honeypot: fake CMS/admin panels, exploit tagging, credential capture."""
from __future__ import annotations

import base64
import datetime as dt
import os
import re
import ssl
from urllib.parse import parse_qs, unquote_plus

from .common import Service, Session, env, env_int, printable

SERVER = env("HN_HTTP_SERVER", "Apache/2.4.41 (Ubuntu)")
MAX_HEADER = 16 * 1024
MAX_BODY = 64 * 1024

TAGS = {
    "log4shell": re.compile(r"\$\{(?:jndi|\$\{|lower|upper)[:}]", re.I),
    "shellshock": re.compile(r"\(\)\s*\{\s*:?;?\s*\}\s*;"),
    "path_traversal": re.compile(r"(?:\.\./|%2e%2e[/%]|\.\.\\|/etc/passwd|/proc/self|boot\.ini|win\.ini)", re.I),
    "sqli": re.compile(r"(?:union(?:\s|/\*.*?\*/|\+)+select|or\s+1\s*=\s*1|'\s*or\s*'|sleep\s*\(|benchmark\s*\(|information_schema)", re.I),
    "xss": re.compile(r"<script|javascript:|onerror\s*=|onload\s*=", re.I),
    "cmd_injection": re.compile(r"(?:[;|&`]|\$\()\s*(?:wget|curl|sh|bash|nc|ncat|python|perl|php|chmod|cat|id|uname)\b", re.I),
    "php_rce": re.compile(r"(?:eval-stdin\.php|allow_url_include|auto_prepend_file|php://input|phpunit)", re.I),
    "env_probe": re.compile(r"(?:/\.env|/\.git/|/\.aws/|/\.ssh/|/config\.php\.bak|/wp-config|\.sql$|\.bak$)", re.I),
    "scanner": re.compile(r"(?:nikto|sqlmap|nmap|masscan|zgrab|nuclei|dirbuster|gobuster|wpscan|acunetix|censys|shodan)", re.I),
    "iot_exploit": re.compile(r"(?:/boaform/|/GponForm/|/cgi-bin/(?:luci|\.\.)|/HNAP1|/setup\.cgi|/shell\?|/ctrlt/DeviceUpgrade|/vendor/phpunit)", re.I),
    "spring_actuator": re.compile(r"/actuator|/jolokia|/h2-console", re.I),
}

WP_LOGIN = """<!DOCTYPE html><html lang="en-US"><head><meta charset="UTF-8"><title>Log In &lsaquo; Acme Corp &#8212; WordPress</title></head>
<body class="login"><div id="login"><h1><a href="https://wordpress.org/">Powered by WordPress</a></h1>
{err}<form name="loginform" id="loginform" action="/wp-login.php" method="post">
<p><label>Username or Email Address<input type="text" name="log" id="user_login"></label></p>
<p><label>Password<input type="password" name="pwd" id="user_pass"></label></p>
<p class="submit"><input type="submit" name="wp-submit" value="Log In"></p></form></div></body></html>"""
PMA = """<!DOCTYPE html><html><head><title>phpMyAdmin</title></head><body><h1>Welcome to phpMyAdmin</h1>{err}
<form method="post" action="/phpmyadmin/index.php"><input name="pma_username"><input type="password" name="pma_password">
<input type="submit" value="Go"></form></body></html>"""
GENERIC_LOGIN = """<!DOCTYPE html><html><head><title>Administration Login</title></head><body><h2>Sign in</h2>{err}
<form method="post"><input name="username"><input type="password" name="password"><button>Login</button></form></body></html>"""
APACHE_INDEX = """<!DOCTYPE html><html><head><title>Apache2 Ubuntu Default Page: It works</title></head><body>
<h1>Apache2 Ubuntu Default Page</h1><p>It works!</p><p>This is the default welcome page used to test the correct operation of the Apache2 server after installation on Ubuntu systems.</p></body></html>"""
ENV_DECOY = "APP_ENV=production\nAPP_DEBUG=false\nDB_HOST=10.0.3.12\nDB_DATABASE=acme\nDB_USERNAME=acme_app\nDB_PASSWORD=Sup3rS3cret-DECOY\nAWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE\nAWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n"
GIT_DECOY = "[core]\n\trepositoryformatversion = 0\n\tfilemode = true\n[remote \"origin\"]\n\turl = git@github.com:acme-corp/internal-portal.git\n"
NOT_FOUND = ("<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\"><html><head><title>404 Not Found</title></head>"
             "<body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>")


def classify(text: str) -> list[str]:
    return sorted(name for name, rx in TAGS.items() if rx.search(text))


def ensure_cert(state_dir: str) -> tuple[str, str]:
    """Create (once) a self-signed certificate for the HTTPS honeypot."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    os.makedirs(state_dir, exist_ok=True)
    crt, key = os.path.join(state_dir, "https.crt"), os.path.join(state_dir, "https.key")
    if os.path.exists(crt) and os.path.exists(key):
        return crt, key
    k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
                      x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Acme Corp")])
    now = dt.datetime.now(dt.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(k.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - dt.timedelta(days=1))
            .not_valid_after(now + dt.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost")]), critical=False)
            .sign(k, hashes.SHA256()))
    with open(key, "wb") as f:
        f.write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                serialization.NoEncryption()))
    os.chmod(key, 0o600)
    with open(crt, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    return crt, key


def make_ssl_context(state_dir: str) -> ssl.SSLContext:
    crt, key = ensure_cert(state_dir)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(crt, key)
    return ctx


class HTTPService(Service):
    name = "http"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.max_requests = env_int("HN_HTTP_MAX_REQUESTS", 20)

    async def handle(self, s: Session) -> None:
        for _ in range(self.max_requests):
            try:
                head = await s.reader.readuntil(b"\r\n\r\n")
            except Exception as e:  # incomplete / overrun / timeout
                partial = getattr(e, "partial", b"") or b""
                if partial:
                    self._raw(s, partial)
                return
            s.bytes_in += len(head)
            if len(head) > MAX_HEADER:
                return
            try:
                first, *hlines = head.decode("latin-1").split("\r\n")
                # scanners often send unencoded spaces in the target: split version off the right
                method, rest = first.split(" ", 1)
                target, _, version = rest.rpartition(" ")
                if not version.startswith("HTTP/") or not method.isalpha() or not target:
                    raise ValueError
            except ValueError:
                self._raw(s, head)
                await s.send(b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                return
            headers = {}
            for h in hlines:
                if ":" in h:
                    k, _, v = h.partition(":")
                    headers[k.strip().lower()] = v.strip()
            body = b""
            try:
                clen = min(int(headers.get("content-length", "0") or 0), MAX_BODY)
            except ValueError:
                clen = 0
            if clen > 0:
                body = await s.readexactly(clen, timeout=15)
            await self._respond(s, method, target, version, headers, body)
            if headers.get("connection", "").lower() == "close" or version == "HTTP/1.0":
                return

    def _raw(self, s: Session, data: bytes) -> None:
        kind = "tls_clienthello_on_http" if data[:2] == b"\x16\x03" else "non_http"
        s.log("raw_request", kind=kind, hex=data[:128].hex(), text=printable(data, 256))

    async def _respond(self, s: Session, method: str, target: str, version: str,
                       headers: dict, body: bytes) -> None:
        path, _, query = target.partition("?")
        body_text = body.decode("utf-8", "replace")
        blob = f"{target}\n{body_text}\n" + "\n".join(f"{k}: {v}" for k, v in headers.items())
        tags = classify(blob)
        if headers.get("user-agent") is None:
            tags.append("no_user_agent")
        creds = self._creds(path, headers, body_text, query)
        s.log("request", method=method, path=path[:1024], query=query[:1024],
              user_agent=headers.get("user-agent", ""), host=headers.get("host", ""),
              headers={k: v for k, v in headers.items() if k not in ("cookie",)},
              body=body_text[:2048], tags=tags, https=bool(s.writer.get_extra_info("ssl_object")))
        if creds:
            s.log("auth", username=creds[0], password=creds[1], method="http_form", success=False, path=path)
        status, ctype, payload, extra = self._route(method, path, creds is not None)
        hdrs = [f"HTTP/1.1 {status}", f"Server: {SERVER}", f"Content-Type: {ctype}",
                f"Content-Length: {len(payload)}", "Connection: keep-alive"] + extra
        await s.send("\r\n".join(hdrs).encode() + b"\r\n\r\n" + (b"" if method == "HEAD" else payload))

    def _creds(self, path: str, headers: dict, body: str, query: str):
        auth = headers.get("authorization", "")
        if auth.lower().startswith("basic "):
            try:
                u, _, p = base64.b64decode(auth[6:]).decode("utf-8", "replace").partition(":")
                return u, p
            except Exception:
                pass
        if body:
            form = parse_qs(body, keep_blank_values=True)
            for uk, pk in (("log", "pwd"), ("pma_username", "pma_password"), ("username", "password"),
                           ("user", "pass"), ("user", "password"), ("login", "password"),
                           ("email", "password"), ("j_username", "j_password"), ("uname", "pass")):
                if uk in form and pk in form:
                    return unquote_plus(form[uk][0]), unquote_plus(form[pk][0])
        return None

    def _route(self, method: str, path: str, had_creds: bool):
        p = path.lower().rstrip("/") or "/"
        html = "text/html; charset=UTF-8"
        err = '<div id="login_error">Invalid username or password.</div>' if had_creds else ""
        if p in ("/wp-login.php", "/wp-admin"):
            return "200 OK", html, WP_LOGIN.format(err=err).encode(), []
        if p.startswith("/phpmyadmin") or p.startswith("/pma"):
            return "200 OK", html, PMA.format(err=err).encode(), []
        if p in ("/admin", "/login", "/administrator", "/user/login", "/signin", "/console"):
            return "200 OK", html, GENERIC_LOGIN.format(err=err).encode(), []
        if p.startswith("/manager") or p.startswith("/host-manager"):
            return "401 Unauthorized", html, b"<h1>401 Unauthorized</h1>", \
                ['WWW-Authenticate: Basic realm="Tomcat Manager Application"']
        if p == "/.env":
            return "200 OK", "text/plain", ENV_DECOY.encode(), []
        if p == "/.git/config":
            return "200 OK", "text/plain", GIT_DECOY.encode(), []
        if p == "/robots.txt":
            return "200 OK", "text/plain", b"User-agent: *\nDisallow: /admin\nDisallow: /backup\nDisallow: /wp-admin\n", []
        if p == "/xmlrpc.php":
            return "405 Method Not Allowed", "text/plain", b"XML-RPC server accepts POST requests only.", []
        if p in ("/server-status", "/server-info"):
            return "403 Forbidden", html, NOT_FOUND.replace("404 Not Found", "403 Forbidden").encode(), []
        if p == "/":
            return "200 OK", html, APACHE_INDEX.encode(), []
        return "404 Not Found", html, NOT_FOUND.encode(), []
