import json
import os
import sys
import time
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "dashboard"))
from app.db import DB, Ingestor  # noqa: E402
from app.main import create_app  # noqa: E402
from app.alerts import Alerter  # noqa: E402

AUTH = ("admin", "correct-horse-battery")


def ev(service="ssh", event="auth", ip="203.0.113.7", ts=None, **data):
    ts = ts or time.time()
    return {"ts": datetime.fromtimestamp(ts, timezone.utc).isoformat(), "sensor": "t", "service": service,
            "event": event, "src_ip": ip, "src_port": 4444, "dst_port": 22, "session": "s1", "data": data}


def write(path, events, mode="a"):
    with open(path, mode) as f:
        for e in events:
            f.write(json.dumps(e) + "\n")


@pytest.fixture
def env(tmp_path):
    logs = tmp_path / "logs"
    logs.mkdir()
    cfg = {"user": "admin", "password": AUTH[1], "db": str(tmp_path / "db" / "t.sqlite"), "logs": str(logs),
           "geoip": "", "webhook": None}
    return cfg, logs


def test_refuses_weak_password(env):
    cfg, _ = env
    cfg["password"] = "short"
    with pytest.raises(SystemExit):
        create_app(cfg)


def test_ingest_rotation_and_partial_lines(env):
    cfg, logs = env
    db = DB(cfg["db"])
    ing = Ingestor(db, str(logs))
    f = logs / "ssh.jsonl"
    write(f, [ev(username="root", password="a", success=False), ev(event="command", command="ls")])
    with open(f, "a") as fh:  # partial line must NOT be consumed yet
        fh.write('{"ts":"2026-01-01T00:00:00+00:00","service":"ssh","event":"auth","da')
    assert ing.scan() == 2
    assert ing.scan() == 0
    with open(f, "a") as fh:
        fh.write('ta":{"username":"x"}}\n')
    assert ing.scan() == 1
    # rotate: old -> .1, new file with fresh inode; unread tail of old must still be ingested
    write(f, [ev(username="late", password="p")])
    os.rename(f, str(f) + ".1")
    write(f, [ev(username="new", password="p")], mode="w")
    assert ing.scan() == 2
    users = {r["username"] for r in db.query("SELECT username FROM events")}
    assert {"root", "late", "new", "x"} <= users
    assert db.query("SELECT COUNT(*) n FROM events")[0]["n"] == 5  # exactly once


def test_api_and_auth(env):
    cfg, logs = env
    write(logs / "ssh.jsonl", [
        ev(username="root", password="123456", success=False),
        ev(username="root", password="123456", success=False, ip="198.51.100.2"),
        ev(username="admin", password="x", success=True),
        ev(event="command", command="uname -a"),
        ev(service="http", event="request", method="GET", path="/.env", user_agent="curl/8", tags=["env_probe"]),
    ])
    app = create_app(cfg)
    with TestClient(app) as c:
        assert c.get("/healthz").status_code == 200
        assert c.get("/api/summary").status_code == 401
        assert c.get("/api/summary", auth=("admin", "wrong-password-xx")).status_code == 401
        deadline = time.time() + 10
        while time.time() < deadline and app.state.ingestor.ingested < 5:
            time.sleep(0.2)
        s = c.get("/api/summary?hours=1", auth=AUTH).json()
        assert s["events"] == 5 and s["ips"] == 2 and s["logins"] == 1 and s["commands"] == 1
        top = c.get("/api/top?field=password&hours=1", auth=AUTH).json()
        assert top[0] == {"value": "123456", "n": 2}
        assert c.get("/api/top?field=password;DROP", auth=AUTH).status_code == 400
        evs = c.get("/api/events?q=uname", auth=AUTH).json()
        assert len(evs) == 1 and evs[0]["command"] == "uname -a"
        assert c.get("/api/events?q=%25", auth=AUTH).json() == []  # % is escaped, not a wildcard
        assert c.get("/api/attacker/203.0.113.7", auth=AUTH).json()["events"] == 4
        assert c.get("/api/attacker/9.9.9.9", auth=AUTH).status_code == 404
        tl = c.get("/api/timeline?hours=1", auth=AUTH).json()
        assert sum(sum(v) for v in tl["series"].values()) == 5
        csv_ = c.get("/api/export?fmt=csv&hours=1", auth=AUTH).text
        assert csv_.count("\n") == 6
        assert "honeynest_events_total" in c.get("/metrics", auth=AUTH).text
        r = c.get("/", auth=AUTH)
        assert r.status_code == 200 and "default-src 'none'" in r.headers["content-security-policy"]
        assert c.get("/static/app.js", auth=AUTH).status_code == 200
        assert c.get("/static/../main.py", auth=AUTH).status_code in (404, 422)


def test_csv_formula_injection_neutralised(env):
    cfg, logs = env
    write(logs / "ssh.jsonl", [ev(username="=cmd|' /C calc'!A0", password="x")])
    app = create_app(cfg)
    with TestClient(app) as c:
        deadline = time.time() + 10
        while time.time() < deadline and app.state.ingestor.ingested < 1:
            time.sleep(0.2)
        out = c.get("/api/export?fmt=csv&hours=1", auth=AUTH).text
        assert "'=cmd" in out and ",=cmd" not in out


def test_alerter_rate_limit_and_scheme(monkeypatch):
    sent = []
    a = Alerter("https://hooks.example/x", cooldown=60)
    monkeypatch.setattr(a, "_post", lambda m: sent.append(m))
    import threading
    monkeypatch.setattr(threading.Thread, "start", lambda self: self._target(*self._args))
    e = ev(event="login_success", username="root", password="x")
    a.handle(e), a.handle(e)
    assert len(sent) == 1 and "203.0.113.7" in sent[0]
    a.handle(ev(event="connect"))
    assert len(sent) == 1
    assert Alerter("file:///etc/passwd").url is None
