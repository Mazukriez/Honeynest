import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "honeypots"))
sys.path.insert(0, os.path.dirname(__file__))
