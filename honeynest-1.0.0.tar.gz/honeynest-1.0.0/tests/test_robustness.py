"""Fuzz every service with hostile / malformed input: it must never crash or log internal errors."""
import asyncio
import os
import random
import tempfile

import pytest

from test_honeypots import events, free_port  # noqa: F401
from hn.common import EventLogger, Limiter
from hn.mail_ftp import FTPService, SMTPService
from hn.redis_mysql import MySQLService, RedisService
from hn.tcp_catchall import TCPCatchAll
from hn.telnet import TelnetService
from hn.web import HTTPService

SERVICES = [("http", HTTPService), ("ftp", FTPService), ("smtp", SMTPService), ("redis", RedisService),
            ("mysql", MySQLService), ("telnet", TelnetService), ("tcp", TCPCatchAll)]

NASTY = [
    b"", b"\x00" * 1000, b"\xff" * 4096, b"A" * 200_000, b"\r\n" * 5000, b"GET / HTTP/1.1\r\n" + b"X: y\r\n" * 5000,
    b"POST / HTTP/1.1\r\nContent-Length: 99999999999\r\n\r\n", b"POST / HTTP/1.1\r\nContent-Length: -5\r\n\r\nabc",
    b"*99999999\r\n", b"*2\r\n$99999999\r\n", b"*1\r\n$abc\r\n", b"$-1\r\n", b"\xff\xfb\x01\xff\xfa" * 100,
    b"AUTH PLAIN !!!notbase64!!!\r\n", b"\x01\x00\x00\x01" + os.urandom(64), b"\xfe\xff\xfd" * 50,
    "GET /‮\u0000\ud800 HTTP/1.1\r\n\r\n".encode("utf-8", "surrogatepass"),
]


@pytest.mark.asyncio
@pytest.mark.parametrize("name,cls", SERVICES)
async def test_fuzz(name, cls, monkeypatch):
    monkeypatch.setenv("HN_IDLE_TIMEOUT", "1")
    random.seed(7)
    with tempfile.TemporaryDirectory() as d:
        svc = cls(EventLogger(name, d, "t", echo=False), Limiter(max_per_ip=1000))
        port = free_port()
        await svc.start("127.0.0.1", port)
        payloads = NASTY + [os.urandom(random.randint(1, 3000)) for _ in range(40)]

        async def hit(p):
            try:
                r, w = await asyncio.open_connection("127.0.0.1", port)
                w.write(p)
                await w.drain()
                await asyncio.wait_for(r.read(100), 1.5)
                w.close()
            except (asyncio.TimeoutError, ConnectionError, OSError):
                pass

        await asyncio.gather(*(hit(p) for p in payloads))
        await asyncio.sleep(1.5)
        # still alive and serving
        r, w = await asyncio.open_connection("127.0.0.1", port)
        w.close()
        await svc.stop()
        bad = [e for e in events(d, name) if str(e["data"].get("reason", "")).startswith("internal:")]
        assert not bad, bad[:3]
