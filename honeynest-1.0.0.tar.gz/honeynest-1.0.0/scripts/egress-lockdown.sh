#!/usr/bin/env bash
# Block NEW outbound connections from the honeypot network (defence in depth: if an attacker ever
# escaped a honeypot process they could not use the host to attack others). Replies to inbound
# connections keep working. Rules are placed in Docker's DOCKER-USER chain. Not persistent across
# reboot: use `--persist` to install a systemd unit that re-applies them after Docker starts.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run as root" >&2; exit 1; }
SUBNET="${HN_SUBNET:-$(grep -E '^HN_SUBNET=' "$(dirname "$0")/../.env" 2>/dev/null | cut -d= -f2 || true)}"
SUBNET="${SUBNET:-172.31.250.0/24}"
BR="br-honeynet"

apply() {
  iptables -N HN-EGRESS 2>/dev/null || iptables -F HN-EGRESS
  iptables -A HN-EGRESS -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
  iptables -A HN-EGRESS -j LOG --log-prefix "hn-egress-drop: " --log-level 4 -m limit --limit 5/min
  iptables -A HN-EGRESS -j DROP
  iptables -C DOCKER-USER -s "$SUBNET" ! -d "$SUBNET" -j HN-EGRESS 2>/dev/null || \
    iptables -I DOCKER-USER -s "$SUBNET" ! -d "$SUBNET" -j HN-EGRESS
  echo "egress lockdown active for $SUBNET (bridge $BR)"
}
remove() {
  iptables -D DOCKER-USER -s "$SUBNET" ! -d "$SUBNET" -j HN-EGRESS 2>/dev/null || true
  iptables -F HN-EGRESS 2>/dev/null || true; iptables -X HN-EGRESS 2>/dev/null || true
  echo "egress lockdown removed"
}
case "${1:-apply}" in
  apply) apply ;;
  remove) remove ;;
  --persist)
    cat > /etc/systemd/system/honeynest-egress.service <<UNIT
[Unit]
Description=Honeynest honeypot egress lockdown
After=docker.service
Requires=docker.service
[Service]
Type=oneshot
RemainAfterExit=yes
Environment=HN_SUBNET=$SUBNET
ExecStart=$(readlink -f "$0") apply
ExecStop=$(readlink -f "$0") remove
[Install]
WantedBy=multi-user.target
UNIT
    systemctl daemon-reload && systemctl enable --now honeynest-egress.service ;;
  *) echo "usage: $0 [apply|remove|--persist]"; exit 1 ;;
esac
