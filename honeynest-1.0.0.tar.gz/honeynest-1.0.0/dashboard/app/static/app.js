"use strict";
// SECURITY: all attacker-controlled strings are inserted with textContent only (never innerHTML).
const $ = (s) => document.querySelector(s);
const el = (tag, props = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else e.setAttribute(k, v);
  }
  for (const k of kids) if (k != null) e.append(k);
  return e;
};
const COLORS = ["#0b6bcb", "#e8710a", "#1a7f4b", "#9334e6", "#d93025", "#00838f", "#a5851a", "#5f6368", "#c2185b"];
const TOPS = [
  ["src_ip", "Top attacker IPs"], ["country", "Top countries"], ["username", "Usernames tried"],
  ["password", "Passwords tried"], ["command", "Commands run"], ["path", "HTTP paths"],
  ["user_agent", "User agents"], ["dst_port", "Targeted ports"],
];
let hours = 24, oldest = null, newest = 0, timer = null;

async function api(path, params = {}) {
  const u = new URL(path, location.origin);
  for (const [k, v] of Object.entries(params)) if (v !== "" && v != null) u.searchParams.set(k, v);
  const r = await fetch(u, { credentials: "same-origin" });
  if (!r.ok) throw new Error(path + " " + r.status);
  return r.json();
}
const fmt = (n) => Number(n || 0).toLocaleString();
const when = (ts) => new Date(ts * 1000).toLocaleString();

function renderCards(s) {
  const items = [["Events", s.events], ["Unique IPs", s.ips], ["Sessions", s.sessions], ["Auth attempts", s.auths],
    ["Successful logins", s.logins], ["Commands", s.commands], ["Download attempts", s.downloads]];
  const box = $("#cards"); box.replaceChildren();
  for (const [l, n] of items) box.append(el("div", { class: "card" }, el("div", { class: "n", text: fmt(n) }), el("div", { class: "l", text: l })));
  $("#sensors").textContent = (s.sensors || []).map((x) => x.sensor + " (last " + when(x.last_seen) + ")").join(" · ");
  const sel = $("#f-service");
  const have = new Set([...sel.options].map((o) => o.value));
  for (const x of s.by_service) if (!have.has(x.service)) sel.append(el("option", { value: x.service, text: x.service }));
}

function renderTimeline(t) {
  const svg = $("#timeline"); svg.replaceChildren();
  const NS = "http://www.w3.org/2000/svg", W = 960, H = 160, pad = 4;
  const names = Object.keys(t.series);
  const totals = Array.from({ length: t.buckets }, (_, i) => names.reduce((a, n) => a + t.series[n][i], 0));
  const max = Math.max(1, ...totals), bw = W / t.buckets;
  const mk = (n, a) => { const e = document.createElementNS(NS, n); for (const k in a) e.setAttribute(k, a[k]); return e; };
  const stack = new Array(t.buckets).fill(0);
  names.forEach((n, si) => t.series[n].forEach((v, i) => {
    if (!v) return;
    const h = (v / max) * (H - pad * 2);
    stack[i] += h;
    svg.append(mk("rect", { x: i * bw + 1, width: Math.max(bw - 2, 1), y: H - pad - stack[i], height: h, fill: COLORS[si % COLORS.length] }));
  }));
  const lg = $("#legend"); lg.replaceChildren();
  names.forEach((n, i) => lg.append(el("span", { class: "lg c" + (i % COLORS.length), text: "■ " + n + "  " })));
}

function topTable(field, title, rows) {
  const tb = el("tbody");
  if (!rows.length) tb.append(el("tr", {}, el("td", { class: "muted", text: "no data" })));
  for (const r of rows) {
    const v = field === "src_ip" ? el("button", { class: "link", text: String(r.value) }) : document.createTextNode(String(r.value));
    if (field === "src_ip") v.addEventListener("click", () => showAttacker(r.value));
    tb.append(el("tr", {}, el("td", { class: "val" }, v), el("td", { class: "n", text: fmt(r.n) })));
  }
  return el("div", { class: "panel" }, el("h2", { text: title }), el("table", {}, tb));
}

function eventDetail(e) {
  const d = e.data || {}, f = document.createDocumentFragment();
  if (e.tags) for (const t of e.tags.split(",")) if (t) f.append(el("span", { class: "tag", text: t }));
  let txt = "";
  if (e.event === "auth") txt = `${e.username ?? ""} / ${e.password ?? ""}`;
  else if (e.event === "command") txt = e.command || "";
  else if (e.event === "request") txt = `${d.method || ""} ${e.path || ""}${d.query ? "?" + d.query : ""}`;
  else if (e.event === "download_attempt") txt = d.url || "";
  else if (e.event === "payload" || e.event === "raw_request") txt = `${d.protocol || d.kind || ""} ${d.text || ""}`;
  else if (e.event === "mail") txt = `${d.mail_from || ""} → ${(d.rcpt_to || []).join(", ")}`;
  else txt = Object.keys(d).length ? JSON.stringify(d).slice(0, 160) : "";
  const span = el("span", { class: "val", text: txt.slice(0, 300) });
  if (e.event === "auth") span.className = "val " + (e.success ? "ok" : "");
  f.append(span);
  return f;
}

function addRows(rows, append) {
  const tb = $("#events tbody");
  const frag = document.createDocumentFragment();
  for (const e of rows) {
    const ip = el("button", { class: "link", text: e.src_ip + (e.country ? " [" + e.country + "]" : "") });
    ip.addEventListener("click", () => showAttacker(e.src_ip));
    frag.append(el("tr", {}, el("td", { text: when(e.ts) }), el("td", { text: e.service + ":" + (e.dst_port ?? "") }),
      el("td", { text: e.event }), el("td", {}, ip), el("td", {}, eventDetail(e))));
  }
  append ? tb.append(frag) : tb.prepend(frag);
}

const filters = () => ({ service: $("#f-service").value, event: $("#f-event").value, q: $("#f-q").value.trim(),
  noise: $("#f-noise").checked ? "true" : "", hours });

async function loadEvents(reset) {
  const p = { ...filters(), limit: 100 };
  if (reset) { $("#events tbody").replaceChildren(); oldest = null; newest = 0; }
  const rows = await api("/api/events", p);
  addRows(rows, true);
  if (rows.length) { oldest = rows[rows.length - 1].id; newest = Math.max(newest, rows[0].id); }
  $("#more").hidden = rows.length < 100;
}
async function loadMore() {
  if (!oldest) return;
  const rows = await api("/api/events", { ...filters(), limit: 100, before_id: oldest });
  addRows(rows, true);
  if (rows.length) oldest = rows[rows.length - 1].id;
  $("#more").hidden = rows.length < 100;
}
async function pollNew() {
  if (!newest) return;
  const rows = await api("/api/events", { ...filters(), limit: 100, after_id: newest });
  if (rows.length) { addRows(rows, false); newest = rows[0].id; }
}

async function showAttacker(ip) {
  const a = await api("/api/attacker/" + encodeURIComponent(ip));
  const body = $("#attacker-body"); body.replaceChildren();
  body.append(el("h2", { text: a.ip + (a.country ? " (" + a.country + ")" : "") }),
    el("p", { class: "muted", text: `first seen ${when(a.first_seen)} · last seen ${when(a.last_seen)} · ${fmt(a.events)} events · ${fmt(a.sessions)} sessions` }));
  const list = (title, rows, cols) => {
    const tb = el("tbody");
    for (const r of rows) tb.append(el("tr", {}, ...cols.map((c, i) => el("td", { class: i ? "n" : "val", text: String(r[c] ?? "") }))));
    return [el("h2", { text: title }), el("table", {}, tb)];
  };
  body.append(...list("Services", a.services, ["service", "n"]), ...list("Ports", a.ports, ["value", "n"]),
    ...list("Commands", a.commands, ["value", "n"]));
  const cred = el("tbody");
  for (const c of a.credentials) cred.append(el("tr", {}, el("td", { class: "val", text: `${c.username ?? ""} / ${c.password ?? ""}` }), el("td", { class: "n", text: fmt(c.n) })));
  body.append(el("h2", { text: "Credentials" }), el("table", {}, cred));
  $("#attacker").showModal();
}

async function refresh() {
  try {
    const [s, t] = await Promise.all([api("/api/summary", { hours }), api("/api/timeline", { hours })]);
    renderCards(s); renderTimeline(t);
    const tops = await Promise.all(TOPS.map(([f]) => api("/api/top", { field: f, hours, limit: 10 })));
    const box = $("#tops"); box.replaceChildren();
    TOPS.forEach(([f, title], i) => box.append(topTable(f, title, tops[i])));
  } catch (e) { console.error(e); }
}

function setExport() {
  $("#dl-json").href = `/api/export?fmt=ndjson&hours=${hours}`;
  $("#dl-csv").href = `/api/export?fmt=csv&hours=${hours}`;
}
async function full() { setExport(); await refresh(); await loadEvents(true); }

$("#range").addEventListener("change", (e) => { hours = Number(e.target.value); full(); });
for (const id of ["#f-service", "#f-event", "#f-noise"]) $(id).addEventListener("change", () => loadEvents(true));
let deb; $("#f-q").addEventListener("input", () => { clearTimeout(deb); deb = setTimeout(() => loadEvents(true), 350); });
$("#more").addEventListener("click", loadMore);
full();
setInterval(() => { if (!document.hidden) { refresh(); pollNew().catch(() => {}); } }, 10000);
