"""Honeynest dashboard: ingestion + REST API + static UI. Everything behind HTTP Basic auth."""
from __future__ import annotations

import csv
import io
import json
import logging
import os
import secrets
import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, PlainTextResponse, StreamingResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from .alerts import Alerter
from .db import DB, TOP_FIELDS, TOP_FILTER, Ingestor, make_geo

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("dashboard")

STATIC = os.path.join(os.path.dirname(__file__), "static")
security = HTTPBasic(auto_error=False)


def settings() -> dict:
    return {
        "user": os.environ.get("DASH_USER", "admin"),
        "password": os.environ.get("DASH_PASSWORD", ""),
        "db": os.environ.get("DB_PATH", "/data/db/honeynest.sqlite"),
        "logs": os.environ.get("LOG_DIR", "/data/logs"),
        "geoip": os.environ.get("GEOIP_DB", "/data/geoip/GeoLite2-Country.mmdb"),
        "webhook": os.environ.get("ALERT_WEBHOOK_URL"),
    }


def create_app(cfg: Optional[dict] = None) -> FastAPI:
    cfg = cfg or settings()
    if len(cfg["password"]) < 12:
        raise SystemExit("DASH_PASSWORD must be set and at least 12 characters (run ./install.sh to generate one)")

    db = DB(cfg["db"])
    alerter = Alerter(cfg["webhook"])
    ingestor = Ingestor(db, cfg["logs"], make_geo(cfg["geoip"]), alerter.handle)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        ingestor.start()
        yield
        ingestor.stop()

    app = FastAPI(title="Honeynest", version="1.0.0", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    def auth(creds: Optional[HTTPBasicCredentials] = Depends(security)) -> str:
        ok = creds is not None and \
            secrets.compare_digest(creds.username.encode(), cfg["user"].encode()) & \
            secrets.compare_digest(creds.password.encode(), cfg["password"].encode())
        if not ok:
            time.sleep(0.5)  # blunt brute-force slow-down
            raise HTTPException(401, "Unauthorized", headers={"WWW-Authenticate": 'Basic realm="Honeynest"'})
        return creds.username

    @app.middleware("http")
    async def sec_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["Content-Security-Policy"] = "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    def since(hours: float) -> float:
        return time.time() - hours * 3600

    @app.get("/healthz", include_in_schema=False)
    def healthz():
        return {"status": "ok", "ingested": ingestor.ingested, "ingest_errors": ingestor.errors}

    @app.get("/api/summary")
    def summary(hours: float = Query(24, gt=0, le=24 * 365), _: str = Depends(auth)):
        t = since(hours)
        one = db.query(
            "SELECT COUNT(*) events, COUNT(DISTINCT src_ip) ips, COUNT(DISTINCT session) sessions,"
            " SUM(event='auth') auths, SUM(event='auth' AND success=1) logins,"
            " SUM(event='command') commands, SUM(event='download_attempt') downloads,"
            " MAX(ts) last_ts FROM events WHERE ts>=?", (t,))[0]
        by_service = db.query("SELECT service, COUNT(*) n FROM events WHERE ts>=? AND event!='disconnect' "
                              "GROUP BY service ORDER BY n DESC", (t,))
        return {"hours": hours, **{k: (v or 0) for k, v in one.items()}, "by_service": by_service,
                "sensors": db.query("SELECT sensor, MAX(ts) last_seen FROM events GROUP BY sensor")}

    @app.get("/api/timeline")
    def timeline(hours: float = Query(24, gt=0, le=24 * 365), buckets: int = Query(48, ge=4, le=200),
                 _: str = Depends(auth)):
        t0 = since(hours)
        step = hours * 3600 / buckets
        rows = db.query("SELECT CAST((ts-?)/? AS INTEGER) b, service, COUNT(*) n FROM events "
                        "WHERE ts>=? AND event NOT IN ('connect','disconnect') GROUP BY b, service", (t0, step, t0))
        series: dict[str, list[int]] = {}
        for r in rows:
            b = min(max(int(r["b"]), 0), buckets - 1)
            series.setdefault(r["service"], [0] * buckets)[b] += r["n"]
        return {"start": t0, "step": step, "buckets": buckets, "series": series}

    @app.get("/api/top")
    def top(field: str, hours: float = Query(24, gt=0, le=24 * 365), limit: int = Query(10, ge=1, le=100),
            _: str = Depends(auth)):
        if field not in TOP_FIELDS:
            raise HTTPException(400, "invalid field")
        flt = TOP_FILTER.get(field, "event NOT IN ('connect','disconnect')")
        return db.query(f"SELECT {field} value, COUNT(*) n FROM events WHERE ts>=? AND {field} IS NOT NULL "
                        f"AND {field}!='' AND {flt} GROUP BY {field} ORDER BY n DESC LIMIT ?", (since(hours), limit))

    @app.get("/api/events")
    def events(limit: int = Query(100, ge=1, le=1000), before_id: Optional[int] = None, after_id: Optional[int] = None,
               service: Optional[str] = None, event: Optional[str] = None, ip: Optional[str] = None,
               q: Optional[str] = Query(None, max_length=200), hours: float = Query(24 * 7, gt=0, le=24 * 365),
               noise: bool = False, _: str = Depends(auth)):
        where, args = ["ts>=?"], [since(hours)]
        if not noise:
            where.append("event NOT IN ('connect','disconnect')")
        for col, val in (("service", service), ("event", event), ("src_ip", ip)):
            if val:
                where.append(f"{col}=?")
                args.append(val)
        if before_id:
            where.append("id<?")
            args.append(before_id)
        if after_id:
            where.append("id>?")
            args.append(after_id)
        if q:
            like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            where.append("(username LIKE ? ESCAPE '\\' OR password LIKE ? ESCAPE '\\' OR command LIKE ? ESCAPE '\\' "
                         "OR path LIKE ? ESCAPE '\\' OR data LIKE ? ESCAPE '\\')")
            args += [like] * 5
        rows = db.query(f"SELECT id,ts,service,event,src_ip,src_port,dst_port,session,username,password,command,"
                        f"path,country,tags,success,data FROM events WHERE {' AND '.join(where)} "
                        f"ORDER BY id DESC LIMIT ?", (*args, limit))
        for r in rows:
            r["data"] = json.loads(r["data"]) if r["data"] else {}
        return rows

    @app.get("/api/attacker/{ip}")
    def attacker(ip: str, _: str = Depends(auth)):
        info = db.query("SELECT src_ip ip, MIN(ts) first_seen, MAX(ts) last_seen, COUNT(*) events, "
                        "COUNT(DISTINCT session) sessions, MAX(country) country FROM events WHERE src_ip=?", (ip,))[0]
        if not info["events"]:
            raise HTTPException(404, "unknown ip")
        info["services"] = db.query("SELECT service, COUNT(*) n FROM events WHERE src_ip=? GROUP BY service", (ip,))
        info["ports"] = db.query("SELECT dst_port value, COUNT(*) n FROM events WHERE src_ip=? GROUP BY dst_port ORDER BY n DESC", (ip,))
        info["credentials"] = db.query("SELECT username, password, COUNT(*) n FROM events WHERE src_ip=? AND event='auth' "
                                       "GROUP BY username, password ORDER BY n DESC LIMIT 25", (ip,))
        info["commands"] = db.query("SELECT command value, COUNT(*) n FROM events WHERE src_ip=? AND event='command' "
                                    "GROUP BY command ORDER BY n DESC LIMIT 25", (ip,))
        return info

    @app.get("/api/export")
    def export(fmt: str = Query("ndjson", pattern="^(ndjson|csv)$"), hours: float = Query(24, gt=0, le=24 * 365),
               _: str = Depends(auth)):
        rows = db.query("SELECT * FROM events WHERE ts>=? ORDER BY id", (since(hours),))

        def gen():
            if fmt == "csv":
                buf = io.StringIO()
                w = csv.writer(buf)
                if rows:
                    w.writerow(rows[0].keys())
                for r in rows:
                    # neutralise spreadsheet formula injection from attacker-controlled cells
                    w.writerow([("'" + v) if isinstance(v, str) and v[:1] in "=+-@\t\r" else v for v in r.values()])
                yield buf.getvalue()
            else:
                for r in rows:
                    r["data"] = json.loads(r["data"]) if r["data"] else {}
                    yield json.dumps(r) + "\n"

        mt = "text/csv" if fmt == "csv" else "application/x-ndjson"
        return StreamingResponse(gen(), media_type=mt,
                                 headers={"Content-Disposition": f'attachment; filename="honeynest.{fmt}"'})

    @app.get("/metrics", response_class=PlainTextResponse)
    def metrics(_: str = Depends(auth)):
        lines = ["# HELP honeynest_events_total Events by service/event in the DB", "# TYPE honeynest_events_total gauge"]
        for r in db.query("SELECT service, event, COUNT(*) n FROM events GROUP BY service, event"):
            lines.append(f'honeynest_events_total{{service="{r["service"]}",event="{r["event"]}"}} {r["n"]}')
        lines += ["# TYPE honeynest_ingested_total counter", f"honeynest_ingested_total {ingestor.ingested}",
                  "# TYPE honeynest_ingest_errors_total counter", f"honeynest_ingest_errors_total {ingestor.errors}",
                  "# TYPE honeynest_unique_ips_24h gauge",
                  f"honeynest_unique_ips_24h {db.query('SELECT COUNT(DISTINCT src_ip) n FROM events WHERE ts>=?', (since(24),))[0]['n']}"]
        return "\n".join(lines) + "\n"

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon():
        return Response(status_code=204)

    @app.get("/", include_in_schema=False)
    def index(_: str = Depends(auth)):
        return FileResponse(os.path.join(STATIC, "index.html"))

    @app.get("/static/{name}", include_in_schema=False)
    def static_files(name: str, _: str = Depends(auth)):
        if name not in ("app.js", "style.css"):
            raise HTTPException(404)
        return FileResponse(os.path.join(STATIC, name))

    app.state.db, app.state.ingestor = db, ingestor
    return app


def get_app() -> FastAPI:  # uvicorn --factory
    return create_app()

