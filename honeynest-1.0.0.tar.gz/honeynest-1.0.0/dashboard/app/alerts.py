"""Optional webhook alerts (Slack / Discord / Mattermost / generic JSON)."""
from __future__ import annotations

import json
import logging
import threading
import time
import urllib.request
from urllib.parse import urlparse

log = logging.getLogger("dashboard.alerts")

ALERT_EVENTS = {"login_success", "download_attempt", "pipe_to_shell"}


def _clean(s: object, n: int = 200) -> str:
    # attacker-controlled text: keep it printable and short; neutralise mentions
    t = "".join(ch if 32 <= ord(ch) < 127 else "?" for ch in str(s))[:n]
    return t.replace("@", "(at)").replace("`", "'")


class Alerter:
    def __init__(self, url: str | None, cooldown: int = 60):
        self.url = url if url and urlparse(url).scheme in ("http", "https") else None
        self.cooldown = cooldown
        self._last: dict[tuple, float] = {}
        if url and not self.url:
            log.warning("ALERT_WEBHOOK_URL ignored (must be http/https)")

    def handle(self, e: dict) -> None:
        if not self.url or e.get("event") not in ALERT_EVENTS:
            return
        key = (e.get("src_ip"), e.get("event"))
        now = time.time()
        if now - self._last.get(key, 0) < self.cooldown:
            return
        self._last[key] = now
        if len(self._last) > 10000:
            self._last = {k: v for k, v in self._last.items() if now - v < self.cooldown}
        d = e.get("data") or {}
        detail = d.get("url") or d.get("command") or (f"user={d.get('username')}" if d.get("username") else "")
        msg = f"[Honeynest] {e.get('service')}/{e.get('event')} from {_clean(e.get('src_ip'))} — {_clean(detail)}"
        threading.Thread(target=self._post, args=(msg,), daemon=True).start()

    def _post(self, msg: str) -> None:
        body = json.dumps({"text": msg, "content": msg}).encode()
        req = urllib.request.Request(self.url, data=body, headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=5).read()
        except Exception as e:
            log.warning("alert delivery failed: %s", e)
