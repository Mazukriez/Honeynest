"""SQLite storage + ingestion of honeypot JSONL logs."""
from __future__ import annotations

import glob
import json
import logging
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from typing import Callable, Iterator

log = logging.getLogger("dashboard.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, sensor TEXT, service TEXT NOT NULL, event TEXT NOT NULL,
  src_ip TEXT, src_port INTEGER, dst_port INTEGER, session TEXT,
  username TEXT, password TEXT, command TEXT, path TEXT, user_agent TEXT,
  country TEXT, tags TEXT, success INTEGER, data TEXT
);
CREATE INDEX IF NOT EXISTS ix_ts ON events(ts);
CREATE INDEX IF NOT EXISTS ix_ip ON events(src_ip, ts);
CREATE INDEX IF NOT EXISTS ix_svc ON events(service, event, ts);
CREATE TABLE IF NOT EXISTS ingest_state(path TEXT PRIMARY KEY, inode INTEGER, offset INTEGER);
"""

TOP_FIELDS = {"src_ip", "username", "password", "command", "path", "user_agent", "country", "dst_port",
              "service", "event"}
# which events feed which "top" list
TOP_FILTER = {"username": "event='auth'", "password": "event='auth' AND password!=''",
              "command": "event='command'", "path": "event='request'", "user_agent": "event='request'"}


def parse_ts(s: str) -> float:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except (ValueError, AttributeError):
        return time.time()


def row_from_event(e: dict, country: str | None) -> tuple:
    d = e.get("data") or {}
    tags = d.get("tags") or []
    succ = d.get("success")
    return (
        parse_ts(e.get("ts", "")), e.get("sensor"), str(e.get("service", "?")), str(e.get("event", "?")),
        e.get("src_ip"), e.get("src_port"), e.get("dst_port"), e.get("session"),
        d.get("username"), d.get("password"), d.get("command"), d.get("path"), d.get("user_agent"),
        country, ",".join(tags) if isinstance(tags, list) else str(tags),
        None if succ is None else int(bool(succ)), json.dumps(d, separators=(",", ":")),
    )


class DB:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with self.conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def conn(self) -> Iterator[sqlite3.Connection]:
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        try:
            yield c
            c.commit()
        finally:
            c.close()

    def query(self, sql: str, args: tuple = ()) -> list[dict]:
        with self.conn() as c:
            return [dict(r) for r in c.execute(sql, args).fetchall()]

    def purge(self, days: int) -> int:
        with self.conn() as c:
            n = c.execute("DELETE FROM events WHERE ts < ?", (time.time() - days * 86400,)).rowcount
        return n


class Ingestor(threading.Thread):
    """Tails *.jsonl files (rotation-safe) into SQLite."""

    def __init__(self, db: DB, log_dir: str, geo: Callable[[str], str | None] = lambda ip: None,
                 on_event: Callable[[dict], None] | None = None, interval: float = 1.0):
        super().__init__(daemon=True, name="ingestor")
        self.db, self.log_dir, self.geo = db, log_dir, geo
        self.on_event = on_event
        self.interval = interval
        self._stop = threading.Event()
        self.ingested = 0
        self.errors = 0
        self._geo_cache: dict[str, str | None] = {}

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        last_purge = 0.0
        retention = int(os.environ.get("RETENTION_DAYS", "90"))
        while not self._stop.is_set():
            try:
                self.scan()
                if time.time() - last_purge > 3600:
                    last_purge = time.time()
                    if retention > 0:
                        n = self.db.purge(retention)
                        if n:
                            log.info("purged %d events older than %d days", n, retention)
            except Exception:
                self.errors += 1
                log.exception("ingest failure")
            self._stop.wait(self.interval)

    def _country(self, ip: str | None) -> str | None:
        if not ip:
            return None
        if ip not in self._geo_cache:
            if len(self._geo_cache) > 50000:
                self._geo_cache.clear()
            try:
                self._geo_cache[ip] = self.geo(ip)
            except Exception:
                self._geo_cache[ip] = None
        return self._geo_cache[ip]

    def scan(self) -> int:
        total = 0
        for path in sorted(glob.glob(os.path.join(self.log_dir, "*.jsonl"))):
            total += self._tail(path)
        return total

    def _state(self, c: sqlite3.Connection, path: str) -> tuple[int, int]:
        r = c.execute("SELECT inode, offset FROM ingest_state WHERE path=?", (path,)).fetchone()
        return (r["inode"], r["offset"]) if r else (0, 0)

    def _read_new(self, fpath: str, offset: int) -> tuple[list[dict], int]:
        """Read complete lines from offset. Returns (events, new_offset)."""
        events, new = [], offset
        with open(fpath, "rb") as f:
            f.seek(offset)
            while True:
                line = f.readline()
                if not line or not line.endswith(b"\n"):
                    break  # EOF or partial line: retry next scan
                new += len(line)
                try:
                    e = json.loads(line)
                    if isinstance(e, dict):
                        events.append(e)
                except ValueError:
                    self.errors += 1
        return events, new

    def _tail(self, path: str) -> int:
        try:
            st = os.stat(path)
        except OSError:
            return 0
        batch: list[dict] = []
        with self.db.conn() as c:
            inode, offset = self._state(c, path)
            if inode and inode != st.st_ino:
                # rotated: finish the old file (now path.1) first
                old = path + ".1"
                try:
                    if os.stat(old).st_ino == inode:
                        evs, _ = self._read_new(old, offset)
                        batch += evs
                except OSError:
                    pass
                offset = 0
            elif offset > st.st_size:  # truncated
                offset = 0
            evs, new_off = self._read_new(path, offset)
            batch += evs
            if batch:
                c.executemany("INSERT INTO events(ts,sensor,service,event,src_ip,src_port,dst_port,session,"
                              "username,password,command,path,user_agent,country,tags,success,data) "
                              "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              [row_from_event(e, self._country(e.get("src_ip"))) for e in batch])
            c.execute("INSERT INTO ingest_state(path,inode,offset) VALUES(?,?,?) "
                      "ON CONFLICT(path) DO UPDATE SET inode=excluded.inode, offset=excluded.offset",
                      (path, st.st_ino, new_off))
        self.ingested += len(batch)
        if self.on_event:
            for e in batch:
                try:
                    self.on_event(e)
                except Exception:
                    log.exception("on_event failed")
        return len(batch)


def make_geo(db_path: str | None) -> Callable[[str], str | None]:
    """Optional MaxMind GeoLite2 country lookup; returns None-lookups if unavailable."""
    import ipaddress

    reader = None
    if db_path and os.path.exists(db_path):
        try:
            import geoip2.database  # type: ignore
            reader = geoip2.database.Reader(db_path)
        except Exception as e:  # pragma: no cover
            log.warning("GeoIP disabled: %s", e)

    def lookup(ip: str) -> str | None:
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return None
        if a.is_private or a.is_loopback or a.is_link_local:
            return "PRIVATE"
        if reader is None:
            return None
        try:
            return reader.country(ip).country.iso_code
        except Exception:
            return None

    return lookup

